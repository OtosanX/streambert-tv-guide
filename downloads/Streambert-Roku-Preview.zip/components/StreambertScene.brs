sub init()
    m.actions = m.top.FindNode("actions")
    m.results = m.top.FindNode("results")
    m.status = m.top.FindNode("status")
    m.details = m.top.FindNode("details")
    m.title = m.top.FindNode("title")
    m.description = m.top.FindNode("description")
    m.setup = m.top.FindNode("setup")
    m.video = m.top.FindNode("video")
    m.actions.buttons = ["Trending", "Search", "TMDB token", "Open video URL"]
    m.actions.ObserveField("buttonSelected", "onAction")
    m.results.ObserveField("itemFocused", "showDetails")
    m.results.ObserveField("itemSelected", "showDetails")
    m.video.ObserveField("state", "onVideoState")
    m.token = ""
    m.actions.SetFocus(true)
    requestCatalog("/localToken", "Loading", "", false, "")
end sub

sub showSetup()
    m.results.visible = false
    m.details.visible = false
    m.setup.visible = true
    m.status.text = "Connect TMDB to browse titles. Direct video URLs work without a token."
end sub

sub onAction(event as Object)
    action = event.GetData()
    if action = 0
        if m.token = ""
            showSetup()
        else
            requestCatalog("/trending/all/week", "Trending this week", m.token, false, "")
        end if
    else if action = 1
        if m.token = ""
            showSetup()
        else
            openKeyboard("Search movies and shows", "search")
        end if
    else if action = 2
        openKeyboard("TMDB API Read Access Token", "token")
    else if action = 3
        openKeyboard("Enter an HTTPS .m3u8 or .mp4 URL", "stream")
    end if
end sub

sub openKeyboard(heading as String, purpose as String)
    dialog = CreateObject("roSGNode", "KeyboardDialog")
    dialog.title = heading
    dialog.buttons = ["Continue", "Cancel"]
    if purpose = "token" then dialog.keyboard.textEditBox.secureMode = true
    m.keyboardPurpose = purpose
    dialog.ObserveField("buttonSelected", "onKeyboardSubmit")
    m.top.dialog = dialog
end sub

sub onKeyboardSubmit(event as Object)
    dialog = m.top.dialog
    if dialog = invalid then return
    dialog.close = true
    if event.GetData() <> 0 then return
    value = dialog.text.Trim()
    if value = "" then return
    if m.keyboardPurpose = "token"
        tokenFormat = CreateObject("roRegex", "^[A-Za-z0-9_-]+[.][A-Za-z0-9_-]+[.][A-Za-z0-9_-]+$", "")
        if not tokenFormat.IsMatch(value) or Len(value) > 4096
            showSetup()
            m.status.text = "Enter the long API Read Access Token shown in TMDB API settings."
            return
        end if
        requestCatalog("/configuration", "Checking the token", value, true, "")
    else if m.keyboardPurpose = "search"
        requestCatalog("/search/multi?include_adult=false&query=", "Search results", m.token, false, value)
    else if m.keyboardPurpose = "stream"
        playStream(value)
    end if
end sub

sub requestCatalog(path as String, heading as String, token as String, checking as Boolean, query as String)
    if m.task <> invalid then m.task.control = "stop"
    m.status.text = heading + "…"
    m.heading = heading
    m.task = CreateObject("roSGNode", "CatalogTask")
    m.task.path = path
    m.task.token = token
    m.task.checking = checking
    m.task.query = query
    m.task.ObserveField("result", "onCatalogReceived")
    m.task.control = "run"
end sub

sub onCatalogReceived()
    if m.task = invalid then return
    if m.task.result = invalid then return
    response = m.task.result
    if m.task.path = "/localToken"
        m.token = response.token
        if m.token = ""
            showSetup()
        else
            requestCatalog("/trending/all/week", "Trending this week", m.token, false, "")
        end if
        return
    end if
    if not response.ok
        if m.task.checking then showSetup()
        m.status.text = response.message
        m.actions.SetFocus(true)
        return
    end if
    if m.task.checking
        m.token = m.task.token
        requestCatalog("/trending/all/week", "Trending this week", m.token, false, "")
        return
    end if
    m.setup.visible = false
    m.details.visible = false
    m.items = response.items
    content = CreateObject("roSGNode", "ContentNode")
    for each result in m.items
        item = content.CreateChild("ContentNode")
        item.title = result.title
    end for
    m.results.content = content
    m.results.visible = m.items.Count() > 0
    m.status.text = m.heading
    if m.results.visible
        m.results.SetFocus(true)
        showDetails()
    else
        m.status.text = "No titles found."
        m.actions.SetFocus(true)
    end if
end sub

sub showDetails()
    if m.items = invalid then return
    index = m.results.itemFocused
    if index < 0 or index >= m.items.Count() then return
    item = m.items[index]
    m.title.text = item.title
    m.description.text = item.overview
    m.details.visible = true
end sub

sub playStream(url as String)
    valid = CreateObject("roRegex", "^https://[^/?# @]+[^ @]*[.](m3u8|mp4)([?#][^ @]*)?$", "i")
    if not valid.IsMatch(url)
        m.status.text = "Enter a direct HTTPS link ending in .m3u8 or .mp4."
        return
    end if
    format = "mp4"
    hls = CreateObject("roRegex", "[.]m3u8([?#]|$)", "i")
    if hls.IsMatch(url) then format = "hls"
    content = CreateObject("roSGNode", "ContentNode")
    content.url = url
    content.streamFormat = format
    m.video.content = content
    m.video.visible = true
    m.video.SetFocus(true)
    m.video.control = "play"
end sub

sub closeVideo()
    m.video.visible = false
    m.video.control = "stop"
    m.actions.SetFocus(true)
end sub

sub onVideoState()
    if not m.video.visible then return
    if m.video.state = "finished" or m.video.state = "stopped"
        closeVideo()
    else if m.video.state = "error"
        closeVideo()
        m.status.text = "This video could not play on your Roku."
    end if
end sub

function onKeyEvent(key as String, pressed as Boolean) as Boolean
    if not pressed then return false
    if key = "back" and m.video.visible
        closeVideo()
        return true
    end if
    if key = "down" and m.actions.IsInFocusChain() and m.results.visible
        m.results.SetFocus(true)
        return true
    end if
    if m.results.IsInFocusChain() and (key = "back" or (key = "up" and m.results.itemFocused = 0))
        m.actions.SetFocus(true)
        return true
    end if
    return false
end function
