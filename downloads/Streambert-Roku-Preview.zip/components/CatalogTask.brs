sub init()
    m.top.functionName = "loadCatalog"
end sub

sub loadCatalog()
    registry = CreateObject("roRegistrySection", "streambert")
    if m.top.path = "/localToken"
        m.top.result = { ok: true, token: registry.Read("tmdb") }
        return
    end if
    transfer = CreateObject("roUrlTransfer")
    port = CreateObject("roMessagePort")
    transfer.SetMessagePort(port)
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.SetUrl("https://api.themoviedb.org/3" + m.top.path + transfer.Escape(m.top.query))
    transfer.AddHeader("Authorization", "Bearer " + m.top.token)
    if not transfer.AsyncGetToString()
        m.top.result = { ok: false, message: "Could not reach TMDB." }
        return
    end if
    event = Wait(10000, port)
    if Type(event) <> "roUrlEvent"
        transfer.AsyncCancel()
        m.top.result = { ok: false, message: "TMDB did not respond. Try again." }
        return
    end if
    code = event.GetResponseCode()
    if code = 401 or code = 403
        m.top.result = { ok: false, message: "TMDB rejected the token. Check the API Read Access Token." }
        return
    end if
    if code <> 200
        m.top.result = { ok: false, message: "Could not load the TMDB catalog. Try again." }
        return
    end if
    entries = []
    if m.top.checking
        registry.Write("tmdb", m.top.token)
        registry.Flush()
    else
        response = ParseJson(event.GetString())
        if Type(response) = "roAssociativeArray"
            if Type(response.results) <> "roArray"
                m.top.result = { ok: true, items: entries }
                return
            end if
            for each item in response.results
                if Type(item) = "roAssociativeArray"
                    if item.adult <> true and (item.media_type = "movie" or item.media_type = "tv")
                        title = item.title
                        if title = invalid then title = item.name
                        overview = item.overview
                        if overview = invalid then overview = ""
                        if title <> invalid then entries.Push({ title: title, overview: overview })
                    end if
                end if
                if entries.Count() = 20 then exit for
            end for
        end if
    end if
    m.top.result = { ok: true, items: entries }
end sub
