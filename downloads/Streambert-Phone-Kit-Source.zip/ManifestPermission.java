import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;

public final class ManifestPermission {
    private static ByteBuffer little(byte[] bytes) {
        return ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
    }

    private static String string(ByteBuffer xml, int index) {
        int start = 8 + xml.getInt(28) + xml.getInt(36 + index * 4);
        int length = xml.getShort(start);
        return new String(xml.array(), start + 2, length * 2, StandardCharsets.UTF_16LE);
    }

    public static void main(String[] args) throws Exception {
        byte[] original = Files.readAllBytes(Path.of(args[0]));
        ByteBuffer xml = little(original);
        int poolSize = xml.getInt(12);
        int stringCount = xml.getInt(16);
        int stringsStart = xml.getInt(28);
        if (xml.getInt(0) != 0x00080003 || xml.getInt(8) != 0x001c0001
                || xml.getInt(20) != 0 || xml.getInt(24) != 0 || xml.getInt(32) != 0
                || stringsStart != 28 + stringCount * 4) throw new IllegalArgumentException("Unexpected manifest string pool");

        int permissionStart = -1;
        int permissionEnd = -1;
        int filterStart = -1;
        int filterEnd = -1;
        byte[] action = null;
        byte[] category = null;
        for (int offset = 8 + poolSize; offset < original.length;) {
            int chunkSize = xml.getInt(offset + 4);
            if (chunkSize < 8 || offset + chunkSize > original.length) throw new IllegalArgumentException("Invalid manifest chunk");
            int type = xml.getShort(offset);
            String tag = type == 0x0102 || type == 0x0103 ? string(xml, xml.getInt(offset + 20)) : "";
            if (type == 0x0102 && tag.equals("intent-filter") && filterStart < 0) filterStart = offset;
            if (type == 0x0103 && tag.equals("intent-filter") && filterEnd < 0) filterEnd = offset;
            if (filterStart >= 0 && filterEnd < 0 && type == 0x0102 && chunkSize == 56) {
                if (tag.equals("action")) action = Arrays.copyOfRange(original, offset, offset + 80);
                if (tag.equals("category")) category = Arrays.copyOfRange(original, offset, offset + 80);
            }
            if (type == 0x0102 && chunkSize == 56
                    && string(xml, xml.getInt(offset + 20)).equals("uses-permission")
                    && string(xml, xml.getInt(offset + 44)).equals("android.permission.INTERNET")) {
                int end = offset + chunkSize;
                if (xml.getShort(end) != 0x0103 || xml.getInt(end + 4) != 24) throw new IllegalArgumentException("Unexpected permission end");
                permissionStart = offset;
                permissionEnd = end + 24;
                break;
            }
            offset += chunkSize;
        }
        if (permissionStart < 0 || filterStart < 0 || filterEnd < 0 || action == null || category == null)
            throw new IllegalArgumentException("Manifest templates missing");

        String[] values = {"com.android.providers.tv.permission.WRITE_EPG_DATA",
                "com.truelockmc.streambert.PLAY_NEXT", "android.intent.category.DEFAULT",
                "android.intent.category.BROWSABLE"};
        int dataSize = poolSize - stringsStart;
        var additions = new ByteArrayOutputStream();
        byte[] offsets = new byte[values.length * 4];
        for (int index = 0; index < values.length; index++) {
            little(offsets).putInt(index * 4, dataSize + additions.size());
            byte[] encoded = values[index].getBytes(StandardCharsets.UTF_16LE);
            byte[] newString = new byte[(encoded.length + 7) & ~3];
            little(newString).putShort((short) values[index].length()).put(encoded);
            additions.write(newString);
        }
        byte[] defaultCategory = category.clone();
        little(action).putInt(44, stringCount + 1).putInt(52, stringCount + 1);
        little(defaultCategory).putInt(44, stringCount + 2).putInt(52, stringCount + 2);
        little(category).putInt(44, stringCount + 3).putInt(52, stringCount + 3);
        var linkFilter = new ByteArrayOutputStream();
        linkFilter.write(original, filterStart, xml.getInt(filterStart + 4));
        linkFilter.write(action);
        linkFilter.write(defaultCategory);
        linkFilter.write(category);
        int filterLimit = filterEnd + xml.getInt(filterEnd + 4);
        linkFilter.write(original, filterEnd, filterLimit - filterEnd);

        int poolDelta = offsets.length + additions.size();
        byte[] header = Arrays.copyOfRange(original, 0, 36);
        little(header).putInt(4, original.length + poolDelta + linkFilter.size() + permissionEnd - permissionStart)
                .putInt(12, poolSize + poolDelta).putInt(16, stringCount + values.length)
                .putInt(28, stringsStart + offsets.length);
        byte[] duplicate = Arrays.copyOfRange(original, permissionStart, permissionEnd);
        little(duplicate).putInt(44, stringCount).putInt(52, stringCount);
        var output = new ByteArrayOutputStream();
        output.write(header);
        output.write(original, 36, stringCount * 4);
        output.write(offsets);
        output.write(original, 8 + stringsStart, dataSize);
        additions.writeTo(output);
        output.write(original, 8 + poolSize, filterLimit - 8 - poolSize);
        linkFilter.writeTo(output);
        output.write(original, filterLimit, permissionEnd - filterLimit);
        output.write(duplicate);
        output.write(original, permissionEnd, original.length - permissionEnd);
        Files.write(Path.of(args[1]), output.toByteArray());
    }
}
