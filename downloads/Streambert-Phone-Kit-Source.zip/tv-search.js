import { r as React, I as ui, J as artwork, t as tmdb } from './movie-tRBw6X1o.js';

let lastQuery = '';
let lastPicked = null;
const focus = element => {
  if (element) window.dispatchEvent(new CustomEvent('streambert:restore-home-focus', { detail: element }));
};
const resultKey = item => item.media_type + '-' + item.id;

export default function TvSearch({ apiKey, onSelect, onClose, offline }) {
  const [query, setQuery] = React.useState(lastQuery);
  const [result, setResult] = React.useState({ query: '', items: [], page: 0, pages: 0, error: false });
  const [loading, setLoading] = React.useState(false);
  const root = React.useRef(null);
  const input = React.useRef(null);
  const firstResult = React.useRef(null);
  const pending = React.useRef(0);
  const searchTimer = React.useRef(null);
  const submitting = React.useRef(false);
  const focusResults = React.useRef(false);
  const clean = query.trim();

  React.useEffect(() => {
    if (!lastPicked) input.current?.focus();
    return () => {
      clearTimeout(searchTimer.current);
      pending.current++;
    };
  }, []);

  async function run(value, page = 1, existing = []) {
    if (offline || !value) return;
    const request = ++pending.current;
    setLoading(true);
    try {
      const response = await tmdb('/search/multi?include_adult=false&page=' + page + '&query=' + encodeURIComponent(value), apiKey);
      if (request !== pending.current) return;
      const items = new Map(existing.map(item => [resultKey(item), item]));
      for (const item of response.results || []) {
        if (['movie', 'tv'].includes(item.media_type) && item.id && (item.title || item.name)) {
          items.set(resultKey(item), item);
        }
      }
      setResult({ query: value, items: [...items.values()], page, pages: response.total_pages, error: false });
    } catch (_) {
      if (request === pending.current) setResult({ query: value, items: existing, page: page - 1, pages: page, error: true });
    } finally {
      if (request === pending.current) setLoading(false);
    }
  }

  React.useEffect(() => {
    lastQuery = query;
    if (!clean || offline) {
      pending.current++;
      setLoading(false);
      return;
    }
    searchTimer.current = setTimeout(() => run(clean), 320);
    return () => {
      clearTimeout(searchTimer.current);
      pending.current++;
    };
  }, [clean, offline, apiKey]);

  React.useLayoutEffect(() => {
    if (!root.current || result.query !== clean || !result.items.length) return;
    if (lastPicked) {
      const previous = root.current.querySelector('[data-search-result="' + CSS.escape(lastPicked) + '"]');
      lastPicked = null;
      if (previous) {
        previous.scrollIntoView({ block: 'nearest' });
        focus(previous);
        return;
      }
    }
    if (focusResults.current) {
      focusResults.current = false;
      focus(firstResult.current);
    }
  }, [result, clean]);

  function submit(event) {
    event.preventDefault();
    if (!clean || offline) return;
    input.current?.blur();
    if (result.query === clean && result.items.length && !result.error) {
      focus(firstResult.current);
      return;
    }
    clearTimeout(searchTimer.current);
    focusResults.current = true;
    run(clean);
  }

  function selectItem(event, item) {
    event.preventDefault();
    event.stopPropagation();
    if (submitting.current) return;
    submitting.current = true;
    lastPicked = resultKey(item);
    onSelect(item);
  }

  const results = result.query === clean ? result.items : [];
  return ui.jsxs('div', { className: 'tv-search-overlay', role: 'dialog', 'aria-modal': true,
    'aria-label': 'Search', ref: root, children: [
      ui.jsxs('header', { className: 'tv-search-header', children: [
        ui.jsx('button', { type: 'button', className: 'tv-search-action', 'data-gamepad-close': true,
          onClick: onClose, children: '‹ Back' }),
        ui.jsxs('form', { className: 'tv-search-form', onSubmit: submit, children: [
          ui.jsx('input', { ref: input, type: 'search', value: query, className: 'tv-search-input',
            placeholder: 'Search movies and shows', 'aria-label': 'Search movies and shows',
            autoComplete: 'off', enterKeyHint: 'search',
            onChange: event => { lastPicked = null; setQuery(event.target.value); },
            onKeyDown: event => {
              if (event.key === 'ArrowDown' && firstResult.current) {
                event.preventDefault();
                event.stopPropagation();
                input.current?.blur();
                focus(firstResult.current);
              }
            },
          }),
          ui.jsx('button', { type: 'submit', className: 'tv-search-action', disabled: !clean || offline,
            children: 'Search' }),
          query && ui.jsx('button', { type: 'button', className: 'tv-search-action',
            onClick: () => { setQuery(''); input.current?.focus(); }, children: 'Clear' }),
        ] }),
      ] }),
      ui.jsxs('main', { className: 'tv-search-results', children: [
        ui.jsx('h1', { children: clean ? 'Search Results' : 'Search' }),
        ui.jsx('p', { className: 'tv-search-status', role: 'status', children: offline ? 'Search is unavailable offline.'
          : !clean ? 'Enter a title to find movies and shows.'
          : loading || result.query !== clean ? 'Searching…'
          : result.error ? 'Search couldn’t load. Try again.'
          : !results.length ? 'No matches for “' + clean + '”.' : '' }),
        ui.jsx('div', { className: 'tv-search-grid', children: results.map((item, index) => {
          const name = item.title || item.name;
          const poster = artwork(item.poster_path, 'w342');
          const year = (item.release_date || item.first_air_date || '').slice(0, 4);
          return ui.jsxs('button', { type: 'button', ref: index === 0 ? firstResult : null,
            className: 'tv-search-result', 'data-search-result': resultKey(item),
            onClick: event => selectItem(event, item), children: [
              ui.jsx('span', { className: 'tv-search-poster',
                children: poster ? ui.jsx('img', { src: poster, alt: '', loading: 'lazy' }) : name }),
              ui.jsx('strong', { children: name }),
              ui.jsx('span', { children: [item.media_type === 'tv' ? 'Series' : 'Movie', year].filter(Boolean).join(' · ') }),
            ],
          }, resultKey(item));
        }) }),
        results.length > 0 && result.page < result.pages && ui.jsx('button', {
          type: 'button', className: 'tv-search-action', disabled: loading,
          onClick: () => run(clean, result.page + 1, results), children: 'Load more',
        }),
      ] }),
    ],
  });
}
