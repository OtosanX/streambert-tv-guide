param(
    [Parameter(Mandatory)][string]$OriginalApk,
    [Parameter(Mandatory)][string]$Sdk,
    [Parameter(Mandatory)][string]$JavaHome,
    [Parameter(Mandatory)][string]$OutputApk,
    [string]$KeyStore,
    [switch]$RedesignHome
)

$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $true
$env:JAVA_HOME = $JavaHome
$work = $PSScriptRoot
$build = Join-Path $work 'build'
$tools = Join-Path $Sdk 'build-tools/36.0.0'
$android = Join-Path $Sdk 'platforms/android-34/android.jar'
$java = Join-Path $JavaHome 'bin/java.exe'
$javac = Join-Path $JavaHome 'bin/javac.exe'
$library = Join-Path $Sdk 'cmdline-tools/lib'
$classpath = ((Get-ChildItem $library -Recurse -File -Filter '*.jar' |
    Where-Object Name -Match '^(smali-dexlib2|guava)-' | ForEach-Object FullName) -join ';')
$classes = Join-Path $build 'classes'
$secondary = Join-Path $build 'secondary'
New-Item -ItemType Directory -Force $classes, $secondary | Out-Null

Add-Type -AssemblyName System.IO.Compression.FileSystem
$original = [IO.Compression.ZipFile]::OpenRead($OriginalApk)
try {
    [IO.Compression.ZipFileExtensions]::ExtractToFile(
        $original.GetEntry('classes.dex'), (Join-Path $build 'original.dex'), $true)
    [IO.Compression.ZipFileExtensions]::ExtractToFile(
        $original.GetEntry('AndroidManifest.xml'), (Join-Path $build 'original-manifest.xml'), $true)
} finally {
    $original.Dispose()
}

& $java -cp $classpath (Join-Path $work 'DexFilter.java') (Join-Path $build 'original.dex') (Join-Path $build 'classes.dex')
& $java (Join-Path $work 'ManifestPermission.java') (Join-Path $build 'original-manifest.xml') (Join-Path $build 'manifest.xml')
& $javac --release 8 -encoding UTF-8 -cp $android -d $classes (Join-Path $work 'MainActivity.java') (Join-Path $work 'AndroidTVPlayerActivity.java') (Join-Path $work 'CatalogPlayback.java')
$playerClasses = @(Get-ChildItem $classes -Recurse -Filter '*.class' |
    Where-Object Name -Match '^(AndroidTVPlayerActivity|CatalogPlayback)' | ForEach-Object FullName)
& (Join-Path $tools 'd8.bat') --lib $android --min-api 24 --output $secondary @playerClasses

$unsigned = Join-Path $build 'unsigned.apk'
$aligned = Join-Path $build 'aligned.apk'
$focusStyle = Get-Content -Raw (Join-Path $work 'tv-focus.css')
$playerScript = Get-Content -Raw (Join-Path $work 'streambert-tv-player.js')
$focusPlaceholder = '/* streambert-focus-css */'
if (!$playerScript.Contains($focusPlaceholder)) { throw 'Missing player focus style insertion point' }
$playerFile = Join-Path $build 'player.js'
[IO.File]::WriteAllText($playerFile, $playerScript.Replace($focusPlaceholder, $focusStyle))
$replacements = @{
    'AndroidManifest.xml' = (Join-Path $build 'manifest.xml')
    'classes.dex' = (Join-Path $build 'classes.dex')
    'classes2.dex' = (Join-Path $secondary 'classes.dex')
    'assets/streambert-tv-player.js' = $playerFile
    'assets/streambert-ad-hosts.txt' = (Join-Path $work 'streambert-ad-hosts.txt')
}
$original = [IO.Compression.ZipFile]::OpenRead($OriginalApk)
try {
    $catalogEntry = 'assets/public/assets/index-BtvHnqir.js'
    $reader = [IO.StreamReader]::new($original.GetEntry($catalogEntry).Open())
    try { $catalog = $reader.ReadToEnd() } finally { $reader.Dispose() }
    $navigation = Get-Content -Raw (Join-Path $work 'catalog-tv-navigation.js')
    $functions = @(
        @{ Name = 'ae'; Original = 'function ae\(e\)\{[^\r\n]+?\}(?=const le=new Set)' },
        @{ Name = 'ge'; Original = 'function ge\(e\)\{[^\r\n]+?\}(?=const xe=)' },
        @{ Name = 'be'; Original = 'function be\(e\)\{[^\r\n]+?\}(?=function ve\()' }
    )
    foreach ($item in $functions) {
        $match = [regex]::Match($navigation, ('(?ms)^function {0}\(.*?^\}}' -f $item.Name))
        $originalFunction = [regex]::Match($catalog, $item.Original)
        if (!$match.Success -or !$originalFunction.Success) {
            throw "Unexpected catalog navigation function $($item.Name)"
        }
        $catalog = $catalog.Replace($originalFunction.Value, $match.Value + ' ')
    }
    $focusScroll = 'scrollIntoView?.({block:"nearest",inline:"nearest",behavior:"smooth"})'
    if (!$catalog.Contains($focusScroll)) { throw 'Unexpected catalog focus scroll behavior' }
    $catalog = $catalog.Replace($focusScroll, 'scrollIntoView?.({block:ie.closest(".carousel-item, .tv-home-card")?"center":"nearest",inline:"nearest",behavior:"instant"}),window.dispatchEvent(new Event("streambert:tv-focus"))')
    $backBinding = [regex]::Match($navigation, '(?ms)^function bindAndroidBack\(.*?^\}')
    $originalBack = 'e.setCanGoBack?.(H.length>0||"home"!==f||!!g||v||L);const t=()=>{me()||rt()};return window.addEventListener("streambert:android-back",t),()=>window.removeEventListener("streambert:android-back",t)'
    if (!$backBinding.Success -or !$catalog.Contains($originalBack)) { throw 'Unexpected Android Back handler' }
    $catalog = $catalog.Replace('function ve(){he()||pe(ge(de()))}', $backBinding.Value +
        ' function ve(){const scope=ce(),active=document.activeElement,current=he();if(active!==current&&scope.contains(active)&&active.matches(oe)&&ae(active)){pe(active,{scroll:false});return;}if(!current||!scope.contains(current))pe(ge(de()))}')
    $catalog = $catalog.Replace($originalBack, 'return bindAndroidBack(e,"home"===f,H.length>0||!!g,v||L,rt,()=>{w(!1);P(!1)})')
    $searchLaunch = 'v&&n.jsx(je,{apiKey:e,onSelect:pt,onClose:()=>w(!1),offline:Ce})'
    $routePush = 'ot=t.useCallback((e,t=null)=>{q(e=>[...e,{page:tt.current,selected:nt.current}])'
    $routePop = 'm(t.page),b(t.selected),"function"==typeof gc'
    $keyStart = 'const e=e=>{const t=!!window.streambertAndroidTV'
    if (!$catalog.Contains($searchLaunch) -or !$catalog.Contains($routePush) -or
        !$catalog.Contains($routePop) -or !$catalog.Contains($keyStart)) { throw 'Unexpected Search routing' }
    $setupEntry = 'if(!e&&!c)return n.jsx(Ee,{onSave:ht,onSkip:()=>d(!0)})'
    if (!$catalog.Contains($setupEntry)) { throw 'Unexpected TMDB setup entry' }
    $catalog = 'import TvSearch from "./tv-search.js";import TvSetup from "./tv-setup.js";' + $catalog
    $catalog = $catalog.Replace($setupEntry, 'if(!e&&!c)return n.jsx(TvSetup,{onSave:ht})')
    $replacements['assets/public/assets/tv-setup.js'] = Join-Path $work 'tv-setup.js'
    $replacements['assets/public/tmdb-setup-qr.png'] = Join-Path $work 'tmdb-setup-qr.png'
    $catalog = $catalog.Replace($searchLaunch,
        'v&&n.jsx(TvSearch,{apiKey:e,onSelect:item=>ot(item.media_type==="tv"?"tv":"movie",item,true),onClose:()=>w(!1),offline:Ce})')
    $catalog = $catalog.Replace($routePush,
        'ot=t.useCallback((e,t=null,restoreSearch=false)=>{q(e=>[...e,{page:tt.current,selected:nt.current,restoreSearch}])')
    $catalog = $catalog.Replace($routePop, 'm(t.page),b(t.selected),w(Boolean(t.restoreSearch)),"function"==typeof gc')
    $catalog = $catalog.Replace($keyStart, 'const e=e=>{if(e.defaultPrevented)return;const t=!!window.streambertAndroidTV')
    $replacements['assets/public/assets/tv-search.js'] = Join-Path $work 'tv-search.js'
    $historyEntry = 'bt=t.useCallback(e=>{const t=r.get(o.HISTORY_ENABLED);if(0===t||!1===t)return;'
    if (!$catalog.Contains($historyEntry)) { throw 'Unexpected playback history callback' }
    $catalog = $catalog.Replace($historyEntry, $historyEntry.Replace('if(0===t||!1===t)return;',
        'const trackProgress=t!==0&&t!==false;window.streambertPlayback?.prepare(JSON.stringify({key:ut(e)==="movie"?"movie_"+e.id:"tv_"+e.id+"_s"+e.season+"e"+e.episode,title:e.title||e.name,poster:e.poster_path,season:e.season,episode:e.episode,episodeTitle:e.episodeName,trackProgress}));if(!trackProgress)return;'))
    $watchedCallback = ',wt=t.useCallback(e=>'
    if (!$catalog.Contains($watchedCallback)) { throw 'Unexpected progress callback' }
    $catalog = $catalog.Replace($watchedCallback,
        ',watchProgressEffect=t.useEffect(()=>{const listener=event=>{const entry=event.detail;if(entry)vt(entry.key,entry.percent)};window.addEventListener("streambert:tv-progress",listener);return()=>window.removeEventListener("streambert:tv-progress",listener)},[vt])' + $watchedCallback)
    $resumeFilter = 'return null!=t&&t>2&&t<98'
    if (!$catalog.Contains($resumeFilter)) { throw 'Unexpected Continue Watching filter' }
    $catalog = $catalog.Replace($resumeFilter, 'return t==null||t<98')
    if ($RedesignHome) {
        $legacyHomeImport = 'import("./HomePage-CtWU7Ysn.js")'
        if (!$catalog.Contains($legacyHomeImport) -or !$catalog.Contains('inProgress:St,offline:Ce')) {
            throw 'Unexpected Home entry point'
        }
        $catalog = $catalog.Replace($legacyHomeImport, 'import("./tv-home.js")')
        $catalog = $catalog.Replace('inProgress:St,offline:Ce', 'inProgress:St,saved:G,offline:Ce')
        $replacements['assets/public/assets/tv-home.js'] = Join-Path $work 'tv-home.js'
        $replacements['assets/public/assets/tv-continue.js'] = Join-Path $work 'tv-continue.js'
    }
    $catalogFile = Join-Path $build 'catalog.js'
    [IO.File]::WriteAllText($catalogFile, $catalog)
    $replacements[$catalogEntry] = $catalogFile

    $tvEntry = 'assets/public/assets/tv-BBhKnuzu.js'
    $reader = [IO.StreamReader]::new($original.GetEntry($tvEntry).Open())
    try { $tvBundle = $reader.ReadToEnd() } finally { $reader.Dispose() }
    $autoplayBinding = 'e.useEffect(()=>{En.current=ms},[ms]);'
    if (!$tvBundle.Contains($autoplayBinding)) { throw 'Unexpected TV episode autoplay hook' }
    $tvBundle = 'import bindTvAutoplay from "./tv-autoplay.js";' + $tvBundle.Replace($autoplayBinding,
        $autoplayBinding + 'e.useEffect(()=>bindTvAutoplay({key:os,next:us,play:ds,restricted:wn,getPreference:key=>t.get(n[key])}),[os,us,ds,wn]);const tvResumeStarted=e.useRef(null);e.useEffect(()=>{if(os&&ue.tvResumeKey===os&&tvResumeStarted.current!==os&&!wn){tvResumeStarted.current=os;window.streambertPlayback?.resume(os)}},[os,ue.tvResumeKey,wn]);')
    $tvFile = Join-Path $build 'tv.js'
    [IO.File]::WriteAllText($tvFile, $tvBundle)
    $replacements[$tvEntry] = $tvFile
    $replacements['assets/public/assets/tv-autoplay.js'] = Join-Path $work 'tv-autoplay.js'

    $homeEntry = 'assets/public/assets/HomePage-CtWU7Ysn.js'
    $reader = [IO.StreamReader]::new($original.GetEntry($homeEntry).Open())
    try { $homeBundle = $reader.ReadToEnd() } finally { $reader.Dispose() }
    $autoRotate = 'b.current=setInterval(()=>S(u.current+1),4500)'
    if (!$homeBundle.Contains($autoRotate)) { throw 'Unexpected Home carousel timer' }
    $homeBundle = $homeBundle.Replace($autoRotate, 'b.current=null')
    $oldContinue = 'T.map(e=>{if(!E[e])return null;if("continue"===e)return 0===f.length?null:t.jsxs("div",{className:"section",children:'
    if (!$homeBundle.Contains($oldContinue)) { throw 'Unexpected Home Continue Watching section' }
    $homeBundle = $homeBundle.Replace($oldContinue,
        '["continue",...T.filter(section=>section!=="continue")].map(e=>{if(e!=="continue"&&!E[e])return null;if("continue"===e)return t.jsxs("div",{className:"section tv-continue",children:')
    $continueGrid = 'className:"cards-grid",children:f.map(e=>'
    if (!$homeBundle.Contains($continueGrid)) { throw 'Unexpected Continue Watching cards' }
    $homeBundle = $homeBundle.Replace($continueGrid,
        'className:"cards-grid tv-continue-row",children:!f.length?t.jsx("p",{className:"tv-continue-empty",children:"Titles you start will appear here."}):f.map(e=>')
    $continueKey = 'restricted:r},`${e.media_type}_${e.id}`)})})]},"continue")'
    if (!$homeBundle.Contains($continueKey)) { throw 'Unexpected Continue Watching card key' }
    $homeBundle = $homeBundle.Replace($continueKey, 'restricted:r},s)})})]},"continue")')
    $homeFile = Join-Path $build 'home.js'
    [IO.File]::WriteAllText($homeFile, $homeBundle)
    $replacements[$homeEntry] = $homeFile

    $styleEntry = 'assets/public/assets/index-DpWkGade.css'
    $reader = [IO.StreamReader]::new($original.GetEntry($styleEntry).Open())
    try { $style = $reader.ReadToEnd() } finally { $reader.Dispose() }
    $styleFile = Join-Path $build 'catalog.css'
    $homeStyle = if ($RedesignHome) { Get-Content -Raw (Join-Path $work 'tv-home.css') } else { '' }
    [IO.File]::WriteAllText($styleFile, $style + [Environment]::NewLine +
        '.carousel-section .carousel-btn{display:none}.carousel-section .carousel-dot{pointer-events:none}.tv-continue-row{display:grid;grid-auto-flow:column;grid-auto-columns:clamp(125px,15vw,240px);grid-template-columns:none;overflow-x:auto;padding:6px}.tv-continue-empty{grid-column:span 3;color:var(--text2);white-space:normal}' +
        [Environment]::NewLine + (Get-Content -Raw (Join-Path $work 'tv-search.css')) +
        [Environment]::NewLine + (Get-Content -Raw (Join-Path $work 'tv-setup.css')) +
        [Environment]::NewLine + $homeStyle + [Environment]::NewLine + $focusStyle)
    $replacements[$styleEntry] = $styleFile
    $file = [IO.File]::Create($unsigned)
    try {
        $archive = [IO.Compression.ZipArchive]::new($file, [IO.Compression.ZipArchiveMode]::Create, $true)
        try {
            foreach ($entry in $original.Entries) {
                if ($entry.FullName -like 'META-INF/*' -or $replacements.ContainsKey($entry.FullName)) { continue }
                $compression = if ($entry.FullName -eq 'resources.arsc') {
                    [IO.Compression.CompressionLevel]::NoCompression
                } else {
                    [IO.Compression.CompressionLevel]::Optimal
                }
                $copy = $archive.CreateEntry($entry.FullName, $compression).Open()
                try {
                    $inputStream = $entry.Open()
                    try { $inputStream.CopyTo($copy) } finally { $inputStream.Dispose() }
                } finally {
                    $copy.Dispose()
                }
            }
            foreach ($entry in $replacements.GetEnumerator()) {
                [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $entry.Value, $entry.Key) | Out-Null
            }
        } finally {
            $archive.Dispose()
        }
    } finally {
        $file.Dispose()
    }
} finally {
    $original.Dispose()
}

if (!$KeyStore) {
    $KeyStore = Join-Path $build 'debug.keystore'
    if (!(Test-Path -LiteralPath $KeyStore)) {
        & (Join-Path $JavaHome 'bin/keytool.exe') -genkeypair -keystore $KeyStore -storetype PKCS12 -storepass android -keypass android -alias androiddebugkey -dname 'CN=Android Debug,O=Android,C=US' -keyalg RSA -keysize 2048 -validity 10000
    }
}
& (Join-Path $tools 'zipalign.exe') -f 4 $unsigned $aligned
& (Join-Path $tools 'apksigner.bat') sign --v4-signing-enabled false --ks $KeyStore --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out $OutputApk $aligned
& (Join-Path $tools 'zipalign.exe') -c 4 $OutputApk
& (Join-Path $tools 'apksigner.bat') verify --verbose --print-certs $OutputApk
