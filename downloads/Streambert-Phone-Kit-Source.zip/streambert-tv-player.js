(() => {
  if (window.__streambertTvKey) return;

  const adOverlays = [
    '#ad-overlay', '.ad-overlay', '#popup-ad', '.popup-ad',
    '#qr-code-ad', '.qr-code-ad', '#qr-ad', '.qr-ad',
    'dialog[data-ad]', '[role="dialog"][data-ad]', '[data-ad-overlay]',
    '.vjs-ad-overlay', '.jw-ad-overlay', '.plyr__ads',
  ].join(',');
  const redundantTvControls = [
    '.volume-group', '.lb-fs',
    '[class*="VolumeSlider-module"]', '[class*="MuteButton-module"]', '[class*="FullscreenButton-module"]',
    '.vjs-volume-panel', '.vjs-fullscreen-control', '.plyr__volume', '[data-plyr="fullscreen"]',
    'button[aria-label="Mute" i]', 'button[aria-label="Unmute" i]',
    'button[aria-label="Fullscreen" i]', 'button[aria-label="Full screen" i]',
    'button[aria-label="Enter fullscreen" i]', 'button[aria-label="Exit fullscreen" i]',
    'button[aria-label="Enter full screen" i]', 'button[aria-label="Exit full screen" i]',
    '[role="slider"][aria-label="Volume" i]', 'input[type="range"][aria-label="Volume" i]',
  ].join(',');
  const style = document.createElement('style');
  style.textContent = `
    ${adOverlays} { display: none !important; }
    ${redundantTvControls} { display: none !important; }
    /* streambert-focus-css */
    .streambert-tv-idle-intro { clip-path: inset(100%) !important; pointer-events: none !important; }
    .streambert-tv-anime-audio {
      flex: 0 0 auto; min-width: 40px; height: 40px; padding: 0 6px;
      border: 0; border-radius: 4px; background: transparent; color: #fff;
      font: 700 13px system-ui, sans-serif; cursor: pointer; pointer-events: auto;
    }
    [data-media-player]:has([role="menu"][data-open]) .streambert-tv-anime-audio { visibility: hidden; }
    video:fullscreen, :fullscreen video { object-fit: contain !important; }
  `;
  document.documentElement.append(style);

  const selector = [
    'button', 'input:not([type="hidden"])', 'select', 'textarea', '[contenteditable="true"]',
    '[role="button"]', '[role^="menuitem"]', '[role="option"]', '[role="slider"]',
    '[role="tab"]', '[role="switch"]', '[role="checkbox"]', '[role="radio"]',
    '[tabindex]:not([tabindex="-1"])', '[onclick]:not(a)',
    '.jw-icon', '.jw-settings-content-item', '.vjs-menu-item', '.vjs-control',
    '.plyr__control', '.art-control', '.art-setting-item', '.dplayer-icon',
    '.shaka-controls-button-panel button', 'media-controller [slot="control-bar"] button',
  ].join(',');
  const directions = {
    ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1],
  };
  let focused = null;
  let introButton = null;
  let introDeadline = 0;
  let introExpired = false;
  let menuSelectionUntil = 0;

  function visible(element) {
    if (!(element instanceof HTMLElement) || !element.isConnected
        || element.closest('[hidden], [aria-hidden="true"], [inert]')) return false;
    const rect = element.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0 || rect.right <= 0 || rect.left >= innerWidth
        || rect.bottom <= 0 || rect.top >= innerHeight) return false;
    for (let current = element; current; current = current.parentElement) {
      const style = getComputedStyle(current);
      if (style.visibility !== 'visible' || Number(style.opacity) < 0.05) return false;
    }
    return true;
  }

  function isIntroButton(element) {
    return [element.textContent, element.getAttribute('aria-label'), element.title]
      .some(label => /^skip intro(?:duction)?$/i.test(label?.trim() || ''));
  }

  function updateIntroButton() {
    const buttons = document.querySelectorAll('button, [role="button"], [aria-label*="skip intro" i]');
    const next = [...buttons].find(button => isIntroButton(button) && visible(button)) || null;
    if (!next) {
      introButton?.classList.remove('streambert-tv-idle-intro');
      introButton = null;
      introExpired = false;
      return;
    }
    if (!introButton) introDeadline = performance.now() + 10000;
    if (next !== introButton) {
      introButton?.classList.remove('streambert-tv-idle-intro');
      introButton = next;
    }
    if (performance.now() >= introDeadline) introExpired = true;
    introButton.classList.toggle('streambert-tv-idle-intro', introExpired);
    if (introExpired && focused === introButton) {
      focused.classList.remove('streambert-tv-focus');
      focused.blur();
      focused = null;
    }
  }

  function refreshIntro(event) {
    if (!introExpired && introButton?.contains(event.target)) introDeadline = performance.now() + 10000;
  }

  for (const event of ['focusin', 'pointerover', 'pointerdown', 'click']) {
    document.addEventListener(event, refreshIntro, true);
  }
  setInterval(updateIntroButton, 250);

  const menuSelector = [
    '.lb-menu.show', 'dialog[open]', '[role="dialog"][aria-modal="true"]',
    '[role="menu"]', '.plyr__menu__container:not([hidden])',
    '.vjs-menu.vjs-lock-showing', '.jw-settings-menu.jw-settings-menu-active',
    '.shaka-settings-menu:not(.shaka-hidden)', '.art-settings',
  ].join(',');
  const vidnestMenuSelector = [
    '[class*="SettingsMenu-module"][role="menu"][data-open]',
    '[class*="ServerMenu-module"][role="menu"][data-open]',
  ].join(',');
  const vidnestHost = location.hostname === 'vidnest.fun';
  const animeMode = vidnestHost && location.pathname.match(/^\/anime\/[0-9]+\/[0-9]+\/(sub|dub)\/?$/)?.[1];
  let animeAudioButton = null;
  const otherAnimeMode = animeMode === 'sub' ? 'dub' : 'sub';

  if (animeMode) {
    animeAudioButton = document.createElement('button');
    animeAudioButton.type = 'button';
    animeAudioButton.className = 'streambert-tv-anime-audio';
    animeAudioButton.textContent = animeMode.toUpperCase();
    animeAudioButton.setAttribute('aria-label',
      'Audio: ' + animeMode.toUpperCase() + ' · Switch to ' + otherAnimeMode.toUpperCase());
    animeAudioButton.addEventListener('click', () => {
      const destination = new URL(location.href);
      destination.pathname = destination.pathname.replace(/\/(sub|dub)\/?$/, '/' + otherAnimeMode);
      location.assign(destination.href);
    });
    const mountAudioButton = () => {
      const toolbar = document.querySelector('[data-media-player] [class*="VideoLayout-module"][class*="controlsGroup"]');
      if (!toolbar || toolbar.contains(animeAudioButton)) return;
      const captions = toolbar.querySelector('button[aria-label="Captions"]');
      const settings = toolbar.querySelector('button[aria-label="Settings"]');
      const adjacent = captions || settings?.parentElement;
      if (adjacent && toolbar.contains(adjacent)) adjacent.before(animeAudioButton);
      else toolbar.append(animeAudioButton);
    };
    mountAudioButton();
    setInterval(mountAudioButton, 500);
  }

  function openMenu(scope) {
    const panels = [...scope.querySelectorAll(menuSelector)].reverse();
    const shown = panels.find(element => visible(element) && getComputedStyle(element).pointerEvents !== 'none');
    if (shown && !isVidnestMenu(shown)) return shown;
    const vidnest = panels.find(element => isVidnestMenu(element) && element.getAttribute('aria-hidden') !== 'true'
      && (!shown || element === shown || shown.contains(element)));
    return vidnest || shown || null;
  }

  function menuToggle(menu) {
    if (menu.matches('.lb-menu')) {
      return menu.closest('.player')?.querySelector('.lb-actions .lb-btn.active');
    }
    const labelledBy = menu.getAttribute('aria-labelledby');
    if (labelledBy) {
      const control = menu.ownerDocument.getElementById(labelledBy);
      if (control?.matches('[aria-haspopup="menu"]')
          || (control && menu.id && control.getAttribute('aria-controls') === menu.id)) return control;
    }
    if (menu.id) {
      return menu.ownerDocument.querySelector(
        '[aria-expanded="true"][aria-controls="' + CSS.escape(menu.id) + '"]');
    }
    return menu.closest('.plyr__menu, .vjs-menu-button, .jw-settings, .shaka-overflow-menu')
      ?.querySelector('[aria-expanded="true"]');
  }

  function isVidnestMenu(menu) {
    return menu?.matches(vidnestMenuSelector);
  }

  function dispatchMenuKey(target, key, keyCode) {
    target.dispatchEvent(new KeyboardEvent('keydown', {
      key, code: key, keyCode, bubbles: true, cancelable: true,
    }));
  }

  function closeMenu(menu) {
    if (isVidnestMenu(menu)) {
      const toggle = menuToggle(menu);
      dispatchMenuKey(menu, 'Escape', 27);
      if (toggle) {
        if (!menu.hasAttribute('data-open') && visible(toggle)) focus(toggle);
        else if (menu.matches('[class*="ServerMenu-module"]')) {
          setTimeout(() => {
            if (menu.hasAttribute('data-open') && toggle.getAttribute('aria-expanded') === 'true') {
              dispatchMenuKey(toggle, 'Enter', 13);
            }
            if (!menu.hasAttribute('data-open') && visible(toggle)) focus(toggle);
          }, 100);
        }
      }
      return true;
    }
    const dismiss = [...menu.querySelectorAll(
      '.lb-back, button[aria-label="Back" i], button[aria-label^="Close" i], [data-dismiss]'
    )].find(visible);
    const toggle = menuToggle(menu);
    if (dismiss) dismiss.click();
    else if (toggle && visible(toggle)) toggle.click();
    else if (menu.matches('dialog[open]')) {
      if (menu.dispatchEvent(new Event('cancel', { cancelable: true }))) menu.close();
    } else {
      const target = menu.contains(document.activeElement) ? document.activeElement : menu;
      dispatchMenuKey(target, 'Escape', 27);
    }
    if (!dismiss && toggle && visible(toggle)) focus(toggle);
    return true;
  }

  document.addEventListener('click', event => {
    if (!(event.target instanceof Element)) return;
    const option = event.target.closest('button, [role^="menuitem"], [role="option"]');
    if (option?.closest(menuSelector)) menuSelectionUntil = performance.now() + 3000;
  }, true);

  window.__streambertTvBack = () => {
    const menu = openMenu(document.fullscreenElement || document);
    const wasSelecting = menuSelectionUntil > performance.now();
    menuSelectionUntil = 0;
    if (menu) return closeMenu(menu);
    return wasSelecting;
  };

  function hitPoint(element, rect) {
    const left = Math.max(rect.left, 0);
    const right = Math.min(rect.right, innerWidth);
    const top = Math.max(rect.top, 0);
    const bottom = Math.min(rect.bottom, innerHeight);
    if (right <= left || bottom <= top) return null;
    const x = (left + right) / 2;
    const y = (top + bottom) / 2;
    const hit = document.elementFromPoint(x, y);
    return element.contains(hit) ? [x, y] : null;
  }

  function candidates(scope) {
    return [...scope.querySelectorAll(selector)].flatMap(element => {
      if (!(element instanceof HTMLElement) || element.matches('iframe, video')
        || element.closest('a[href], [aria-hidden="true"], [inert], [aria-disabled="true"]')
        || element.matches(':disabled')) return [];
      if (element.checkVisibility && !element.checkVisibility({
        opacityProperty: true, visibilityProperty: true, contentVisibilityAuto: true,
      })) return [];
      const rect = element.getBoundingClientRect();
      const point = hitPoint(element, rect);
      if (!point) return [];
      const hitControl = document.elementFromPoint(...point)?.closest(selector);
      if (hitControl && hitControl !== element && element.contains(hitControl)) return [];
      return [{ element, point }];
    });
  }

  function focus(element) {
    focused?.classList.remove('streambert-tv-focus');
    focused = element;
    element.classList.add('streambert-tv-focus');
    if (!element.hasAttribute('tabindex') && element.tabIndex < 0) element.tabIndex = -1;
    element.focus({ preventScroll: true });
    element.scrollIntoView({ block: 'nearest', inline: 'nearest' });
  }

  function activeVideo(scope) {
    return [...scope.querySelectorAll('video')].filter(video => {
      const rect = video.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && !video.closest(adOverlays)
        && getComputedStyle(video).visibility !== 'hidden';
    }).sort((left, right) => right.clientWidth * right.clientHeight - left.clientWidth * left.clientHeight)[0];
  }

  function playbackVideo(scope) {
    const local = activeVideo(scope);
    if (local) return local;
    for (const frame of scope.querySelectorAll('iframe')) {
      try {
        if (frame.contentDocument && frame.getBoundingClientRect().height > 0) {
          const video = playbackVideo(frame.contentDocument);
          if (video) return video;
        }
      } catch (_) {}
    }
    return null;
  }

  const observedPlayback = new WeakSet();
  let finishedDuration = 0;
  window.__streambertTvPlayback = resumeAt => {
    const video = playbackVideo(document);
    if (finishedDuration) return [finishedDuration, finishedDuration, true, true];
    if (!video || !Number.isFinite(video.duration) || video.duration < 120) return null;
    if (!observedPlayback.has(video)) {
      observedPlayback.add(video);
      video.addEventListener('ended', () => {
        if (Number.isFinite(video.duration) && video.duration >= 120) finishedDuration = video.duration;
      });
    }
    if (video.ended) return [video.duration, video.duration, true, true];
    if (resumeAt > 0) {
      if (video.currentTime >= resumeAt || resumeAt >= video.duration - 5) {
        return [video.currentTime, video.duration, true];
      }
      for (let index = 0; index < video.seekable.length; index++) {
        if (video.seekable.start(index) <= resumeAt && video.seekable.end(index) >= resumeAt) {
          video.currentTime = resumeAt;
          return [video.currentTime, video.duration, true];
        }
      }
      return null;
    }
    return [video.currentTime, video.duration, true];
  };

  function bestQualityIndex(levels) {
    let best = -1;
    let bestScore = 0;
    Array.from(levels || []).forEach((level, index) => {
      const height = Number(level.height || String(level.label || '').match(/(\d{3,4})p/i)?.[1]);
      const bitrate = Number(level.bitrate || level.bandwidth || 0);
      if (!height && !bitrate) return;
      const score = (height || 0) * 1e9 + bitrate;
      if (score > bestScore) {
        best = index;
        bestScore = score;
      }
    });
    return best;
  }

  function chooseHighestQuality(view) {
    try {
      if (typeof view.jwplayer === 'function') {
        const player = view.jwplayer();
        const best = bestQualityIndex(player?.getQualityLevels?.());
        if (best >= 0 && player.setCurrentQuality) {
          player.setCurrentQuality(best);
          return true;
        }
      }
    } catch (_) {}
    try {
      const hls = view.hls || view.hlsPlayer;
      const best = bestQualityIndex(hls?.levels);
      if (best >= 0 && hls && 'currentLevel' in hls) {
        hls.currentLevel = best;
        return true;
      }
    } catch (_) {}
    try {
      const player = view.player;
      const options = player?.config?.quality?.options;
      if (Array.isArray(options) && 'quality' in player) {
        const highest = Math.max(0, ...options.map(Number).filter(Number.isFinite));
        if (highest > 0) {
          player.quality = highest;
          return true;
        }
      }
    } catch (_) {}
    for (const frame of view.document.querySelectorAll('iframe')) {
      try {
        if (frame.contentDocument && frame.getBoundingClientRect().height > 0
            && chooseHighestQuality(frame.contentWindow)) return true;
      } catch (_) {}
    }
    return false;
  }

  let qualityAttempts = 0;
  const qualityTimer = setInterval(() => {
    if (chooseHighestQuality(window) || ++qualityAttempts >= 20) clearInterval(qualityTimer);
  }, 1500);

  function wakeControls(video) {
    if (!video) return;
    if (vidnestHost) {
      const player = video.closest('[data-media-player]');
      if (player && !player.hasAttribute('data-controls')) {
        player.dispatchEvent(new Event('media-pause-controls-request', { bubbles: true, composed: true }));
        window.clearTimeout(wakeControls.resumeTimer);
        wakeControls.resumeTimer = window.setTimeout(() => player.dispatchEvent(
          new Event('media-resume-controls-request', { bubbles: true, composed: true })), 600);
      }
    }
    const rect = video.getBoundingClientRect();
    const x = Math.min(innerWidth - 1, Math.max(0, rect.left + rect.width / 2));
    const y = Math.min(innerHeight - 1, Math.max(0, rect.bottom - 32));
    const target = document.elementFromPoint(x, y) || video;
    target.dispatchEvent(new PointerEvent('pointermove', {
      bubbles: true, clientX: x, clientY: y, pointerType: 'mouse',
    }));
    target.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, clientX: x, clientY: y }));
  }

  function scroll(direction, element) {
    const [horizontal, vertical] = direction;
    for (let container = element?.parentElement; container; container = container.parentElement) {
      const { overflowX, overflowY } = getComputedStyle(container);
      const axis = horizontal ? overflowX : overflowY;
      if (!/^(auto|scroll)$/.test(axis) && container !== document.scrollingElement) continue;
      const before = horizontal ? container.scrollLeft : container.scrollTop;
      container.scrollBy({ left: horizontal * 120, top: vertical * 120, behavior: 'instant' });
      if (before !== (horizontal ? container.scrollLeft : container.scrollTop)) return true;
    }
    return false;
  }

  function move(key, controls, selected, video) {
    const direction = directions[key];
    const slider = selected?.element;
    const seekSlider = slider?.matches('.jw-slider-time, .vjs-progress-holder, [data-plyr="seek"]')
      || (slider?.matches('input[type="range"], [role="slider"]')
        && /seek|progress|timeline/i.test(slider.getAttribute('aria-label') || slider.title));
    if (seekSlider
        && direction[0] && video?.seekable.length) {
      return seek(video, direction[0] * 5);
    }
    if (!selected && controls.length) {
      focus(controls.find(({ element }) => /play|pause/i.test([
        element.getAttribute('aria-label'), element.title, element.getAttribute('data-plyr'),
      ].join(' ')))?.element || controls[0].element);
      return true;
    }
    const [dx, dy] = direction;
    let best = null;
    let bestScore = Infinity;
    if (selected) {
      for (const control of controls) {
        if (control === selected) continue;
        const deltaX = control.point[0] - selected.point[0];
        const deltaY = control.point[1] - selected.point[1];
        const forward = dx * deltaX + dy * deltaY;
        if (forward <= 2) continue;
        const score = forward + 2.5 * Math.abs(dy * deltaX - dx * deltaY);
        if (score < bestScore) {
          best = control;
          bestScore = score;
        }
      }
    }
    if (best) {
      focus(best.element);
      return true;
    }
    return scroll(direction, selected?.element || document.body) || Boolean(selected);
  }

  function seek(video, delta) {
    if (!video?.seekable.length || !Number.isFinite(video.currentTime)) return false;
    for (let index = 0; index < video.seekable.length; index++) {
      const start = video.seekable.start(index);
      const end = video.seekable.end(index);
      if (video.currentTime >= start && video.currentTime <= end) {
        video.currentTime = Math.max(start, Math.min(end, video.currentTime + delta));
        return true;
      }
    }
    return false;
  }

  function play(video) {
    video.play()?.catch(() => {});
    return true;
  }

  window.__streambertTvKey = key => {
    const scope = document.fullscreenElement || document;
    const video = scope instanceof HTMLVideoElement ? scope : activeVideo(scope);
    if (key.startsWith('KEYCODE_MEDIA_')) {
      if (key === 'KEYCODE_MEDIA_FAST_FORWARD') return seek(video, 10);
      if (key === 'KEYCODE_MEDIA_REWIND') return seek(video, -10);
      if (!video) return false;
      if (key === 'KEYCODE_MEDIA_PLAY' || (key === 'KEYCODE_MEDIA_PLAY_PAUSE' && video.paused)) {
        return play(video);
      }
      video.pause();
      return true;
    }
    const menu = openMenu(scope);
    if (!menu) wakeControls(video);
    const vidnestMenu = isVidnestMenu(menu);
    const controls = vidnestMenu
      ? [...menu.querySelectorAll('[role^="menuitem"]')]
        .filter(element => element.closest('[role="menu"]') === menu
          && !element.matches(':disabled, [aria-disabled="true"]')
          && !element.closest('[hidden], [aria-hidden="true"]'))
        .map(element => ({ element }))
      : candidates(menu || scope);
    const currentFocus = controls.find(item => item.element === focused);
    const browserFocus = controls.find(item => item.element === document.activeElement);
    const selected = browserFocus || currentFocus;
    if (directions[key]) {
      if (vidnestMenu) {
        const [horizontal, vertical] = directions[key];
        const index = selected ? controls.indexOf(selected) + (vertical || horizontal) : 0;
        if (controls[index]) focus(controls[index].element);
        return true;
      }
      if (move(key, controls, selected, menu ? null : video)) return true;
      if (menu) return true;
      const sought = video && !scope.querySelector('iframe') && directions[key][0]
        && seek(video, directions[key][0] * 10);
      return Boolean(sought || vidnestHost);
    }
    if (key !== 'Enter') return false;
    if (!menu && selected?.element === animeAudioButton) return ['anime-audio', otherAnimeMode];
    if (vidnestMenu) {
      if (selected) {
        menuSelectionUntil = performance.now() + 3000;
        dispatchMenuKey(selected.element, 'Enter', 13);
      } else {
        const initial = controls.find(item => item.element.getAttribute('aria-checked') === 'true') || controls[0];
        if (initial) focus(initial.element);
      }
      return true;
    }
    if (vidnestHost && selected?.element.matches('button[aria-haspopup="menu"]')) {
      dispatchMenuKey(selected.element, 'Enter', 13);
      return true;
    }
    if (selected) return [selected.point[0] / innerWidth, selected.point[1] / innerHeight];
    if (menu) {
      if (controls.length) focus(controls[0].element);
      return true;
    }
    if (!video) return vidnestHost;
    if (video.paused) return play(video);
    video.pause();
    return true;
  };
})();
