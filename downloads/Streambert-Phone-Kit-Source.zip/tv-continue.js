export function mediaKey(item) {
  if (item.media_type !== 'tv') return 'movie_' + item.id;
  return 'tv_' + item.id + (item.season == null ? '' : '_s' + item.season + 'e' + item.episode);
}

export function continueQueue(inProgress, history, progress, watched) {
  const group = item => item.media_type + ':' + item.id;
  const latest = new Map();
  for (const item of history || []) {
    if (item.media_type !== 'tv' || item.season == null || item.episode == null) continue;
    const series = group(item);
    const previous = latest.get(series);
    if (!previous || item.watchedAt > previous.watchedAt) latest.set(series, item);
  }
  const queued = new Set();
  return (inProgress || []).filter(item => {
    const key = mediaKey(item);
    const series = group(item);
    if (queued.has(series) || watched?.[key] || progress?.[key] >= 98) return false;
    const newest = latest.get(series);
    if (newest && mediaKey(newest) !== key) return false;
    queued.add(series);
    return true;
  });
}
