import { r as React, I as ui, J as artwork, h as isRestricted, t as tmdb } from './movie-tRBw6X1o.js';
import { u as useRatings, g as ratingFor } from './useRatings-DEnyOz5g.js';
import { continueQueue, mediaKey } from './tv-continue.js';

const regions = { US: 'United States', CA: 'Canada', GB: 'United Kingdom', AU: 'Australia', NZ: 'New Zealand', DE: 'Germany', FR: 'France', IN: 'India' };
const services = [
  { id: 'netflix', label: 'Netflix', match: /^Netflix(?: Standard with Ads| basic with Ads)?$/i },
  { id: 'disney', label: 'Disney+', match: /^Disney Plus(?: with Ads)?$/i },
  { id: 'hbo', label: 'HBO Max', match: /^(?:HBO Max|Max)(?: with Ads)?$/i },
  { id: 'prime', label: 'Prime Video', match: /^Amazon Prime Video(?: with Ads)?$/i },
  { id: 'hulu', label: 'Hulu', match: /^Hulu$/i },
  { id: 'apple', label: 'Apple TV+', match: /^Apple TV(?: Plus|\+)?$/i },
  { id: 'paramount', label: 'Paramount+', match: /^Paramount Plus(?: Premium| Basic with Ads)?$/i },
  { id: 'peacock', label: 'Peacock', match: /^Peacock(?: Premium(?: Plus)?)?$/i },
];
const genres = [
  { id: 'action', title: 'Action Movies', type: 'movie', genre: 28 },
  { id: 'comedy', title: 'Comedy Movies', type: 'movie', genre: 35 },
  { id: 'horror', title: 'Horror Movies', type: 'movie', genre: 27 },
  { id: 'sci-fi', title: 'Sci-Fi & Fantasy Shows', type: 'tv', genre: 10765 },
  { id: 'crime', title: 'Crime Shows', type: 'tv', genre: 80 },
  { id: 'documentary', title: 'Documentaries', type: 'movie', genre: 99 },
];
const empty = [];
let savedFocus = null;

function preference(name, fallback) {
  try { return localStorage.getItem('streambert-home-' + name) || fallback; }
  catch (_) { return fallback; }
}

function store(name, value) {
  try { localStorage.setItem('streambert-home-' + name, value); }
  catch (_) {}
}

function useRequest(enabled, key, request) {
  const [state, update] = React.useState({ key: null, data: null, error: false });
  React.useEffect(() => {
    if (!enabled) return;
    let active = true;
    request().then(data => {
      if (active) update({ key, data, error: false });
    }).catch(() => {
      if (active) update({ key, data: null, error: true });
    });
    return () => { active = false; };
  }, [enabled, key]);
  if (!enabled) return { data: null, loading: false, error: false };
  return state.key === key ? { ...state, loading: false } : { data: null, loading: true, error: false };
}

function list(items, mediaType) {
  return (items || []).filter(item => item.id && (item.title || item.name))
    .map(item => ({ ...item, media_type: mediaType || item.media_type || (item.first_air_date ? 'tv' : 'movie') }));
}

function episodeLabel(item) {
  if (item.season == null || item.episode == null) return '';
  return 'S' + item.season + ' · E' + item.episode + (item.episodeName ? ' · ' + item.episodeName : '');
}

function discover(apiKey, type, region, providerIds, genre) {
  const date = new Date().toISOString().slice(0, 10);
  const query = new URLSearchParams({ sort_by: 'popularity.desc', include_adult: 'false' });
  query.set(type === 'tv' ? 'first_air_date.lte' : 'primary_release_date.lte', date);
  if (genre) query.set('with_genres', String(genre));
  if (providerIds) {
    query.set('watch_region', region);
    query.set('with_watch_providers', providerIds);
    query.set('with_watch_monetization_types', 'flatrate');
  }
  return tmdb('/discover/' + type + '?' + query, apiKey).then(response => list(response.results, type));
}

function catalogKey(item) {
  return item.media_type + ':' + item.id;
}

function recommendationSeeds(history) {
  const seedByType = new Map();
  for (const item of history || []) {
    if (item.id && ['movie', 'tv'].includes(item.media_type) && !seedByType.has(item.media_type)) {
      seedByType.set(item.media_type, item);
    }
  }
  return [...seedByType.values()];
}

async function recommendations(apiKey, seeds) {
  const responses = await Promise.all(seeds.map(item =>
    tmdb('/' + item.media_type + '/' + item.id + '/recommendations', apiKey)
      .then(response => list(response.results, item.media_type)).catch(() => empty)));
  const today = new Date().toISOString().slice(0, 10);
  const combined = new Map();
  for (const row of responses) {
    for (const item of row) {
      const release = item.release_date || item.first_air_date;
      if (!item.adult && (!release || release <= today)) combined.set(catalogKey(item), item);
    }
  }
  return [...combined.values()].sort((left, right) => (right.popularity || 0) - (left.popularity || 0));
}

function providerIds(directory, service, type) {
  return (directory?.[type] || []).filter(provider => service.match.test(provider.provider_name))
    .map(provider => provider.provider_id).join('|');
}

function railHeading(id, title, description) {
  return ui.jsxs('div', { className: 'tv-home-heading', children: [
    ui.jsx('h2', { id: 'home-heading-' + id, children: title }),
    description && ui.jsx('span', { children: description }),
  ] });
}

function HomeRail({ id, title, description, items, message, progress, onPick, rating, resume }) {
  if (!items.length && !message) return null;
  return ui.jsxs('section', { className: 'section tv-home-section', 'aria-labelledby': 'home-heading-' + id, children: [
    railHeading(id, title, description),
    items.length ? ui.jsx('div', { className: 'tv-home-rail', children: items.slice(0, 16).map(item => {
      const key = mediaKey(item);
      const name = item.title || item.name;
      const episode = episodeLabel(item);
      const state = rating(item);
      const poster = artwork(resume ? item.backdrop_path || item.poster_path : item.poster_path, 'w342');
      const percent = progress[key] || 0;
      const focusId = id + '-' + key;
      return ui.jsxs('button', {
        type: 'button',
        className: 'tv-home-card' + (resume ? ' tv-resume-card' : ''),
        'data-home-focus': focusId,
        'aria-label': [resume ? 'Resume ' + name : name, episode].filter(Boolean).join(', '),
        onClick: event => onPick(item, state, event.currentTarget, resume),
        children: [
          ui.jsxs('div', { className: 'tv-home-card-art', children: [
            poster && !state.restricted ? ui.jsx('img', { src: poster, alt: '', loading: 'lazy', draggable: false })
              : ui.jsx('span', { children: state.restricted ? 'Restricted' : name }),
            resume && ui.jsx('span', { className: 'tv-home-play-mark', 'aria-hidden': true, children: '▶' }),
            resume && percent > 0 && ui.jsx('span', { className: 'tv-home-progress',
              children: ui.jsx('span', { style: { width: Math.max(0, Math.min(100, percent)) + '%' } }) }),
          ] }),
          ui.jsx('span', { className: 'tv-home-card-title', children: name }),
          ui.jsx('span', { className: 'tv-home-card-meta',
            children: episode || (item.media_type === 'tv' ? 'Series' : 'Movie') }),
        ],
      }, focusId);
    }) }) : ui.jsx('p', { className: 'tv-home-message', children: message }),
  ] });
}

export default function TvHome({ trending, trendingTV, inProgress, history, watched, saved = {}, progress = {}, apiKey, offline, onSelect }) {
  const [region, setRegion] = React.useState(() => {
    const country = preference('region', 'US');
    return regions[country] ? country : 'US';
  });
  const [selected, setSelected] = React.useState(() => preference('service', 'all'));
  const [regionOpen, setRegionOpen] = React.useState(false);
  const [reload, setReload] = React.useState(0);
  const root = React.useRef(null);
  const regionButton = React.useRef(null);
  const online = Boolean(apiKey && !offline);

  const directory = useRequest(online, region + reload + apiKey, () => Promise.all(['movie', 'tv'].map(type =>
    tmdb('/watch/providers/' + type + '?watch_region=' + region, apiKey)
  )).then(([movies, series]) => ({ movie: movies.results, tv: series.results })));
  const available = services.filter(service => providerIds(directory.data, service, 'movie')
    || providerIds(directory.data, service, 'tv'));
  const service = available.find(option => option.id === selected)
    || (directory.loading ? services.find(option => option.id === selected) : null);
  const all = !service;
  const moviesId = service && providerIds(directory.data, service, 'movie');
  const seriesId = service && providerIds(directory.data, service, 'tv');
  const requestKey = region + ':' + (service?.id || 'all') + ':' + reload + ':' + apiKey;
  const movies = useRequest(online && (all || Boolean(moviesId)), requestKey,
    () => discover(apiKey, 'movie', region, moviesId));
  const series = useRequest(online && (all || Boolean(seriesId)), requestKey,
    () => discover(apiKey, 'tv', region, seriesId));
  const weekly = useRequest(online && all, 'weekly:' + reload + apiKey,
    () => tmdb('/trending/all/week', apiKey).then(response => list(
      (response.results || []).filter(item => ['movie', 'tv'].includes(item.media_type)))));
  const seeds = React.useMemo(() => recommendationSeeds(history), [history]);
  const seen = React.useMemo(() => new Set((history || []).map(catalogKey)), [history]);
  const suggested = useRequest(online && all && seeds.length > 0,
    'suggested:' + seeds.map(catalogKey).join(',') + ':' + reload + ':' + apiKey,
    () => recommendations(apiKey, seeds));
  const genreRows = useRequest(online && (all || Boolean(moviesId || seriesId)), 'genres:' + requestKey,
    () => Promise.all(genres.map(async genre => {
      const idList = genre.type === 'movie' ? moviesId : seriesId;
      if (!all && !idList) return { ...genre, items: empty };
      const items = await discover(apiKey, genre.type, region, idList, genre.genre).catch(() => empty);
      return { ...genre, items };
    })));
  const recent = useRequest(online && all, 'recent:' + region + reload + apiKey, () => {
    const end = new Date();
    const start = new Date(end.getTime() - 45 * 86400000);
    return Promise.all(['movie', 'tv'].map(type => {
      const field = type === 'tv' ? 'first_air_date' : 'primary_release_date';
      return tmdb('/discover/' + type + '?sort_by=popularity.desc&include_adult=false&' + field + '.gte='
        + start.toISOString().slice(0, 10) + '&' + field + '.lte=' + end.toISOString().slice(0, 10), apiKey)
        .then(response => list(response.results, type));
    })).then(([moviesList, seriesList]) => [...moviesList, ...seriesList]
      .sort((left, right) => (right.popularity || 0) - (left.popularity || 0)));
  });

  const fallbackMovies = React.useMemo(() => list(trending, 'movie'), [trending]);
  const fallbackSeries = React.useMemo(() => list(trendingTV, 'tv'), [trendingTV]);
  const myList = React.useMemo(() => list(Object.values(saved)), [saved]);
  const movieItems = movies.data || (all ? fallbackMovies : empty);
  const showItems = series.data || (all ? fallbackSeries : empty);
  const continueItems = React.useMemo(() => continueQueue(inProgress, history, progress, watched),
    [inProgress, history, progress, watched]);
  const recommendedItems = React.useMemo(() => (suggested.data || empty)
    .filter(item => !seen.has(catalogKey(item))).slice(0, 16), [suggested.data, seen]);
  const genreItems = genreRows.data || empty;
  const combined = React.useMemo(() => [
    ...continueItems, ...movieItems, ...showItems, ...recommendedItems,
    ...(weekly.data || []), ...(recent.data || []), ...myList, ...genreItems.flatMap(row => row.items.slice(0, 16)),
  ], [continueItems, movieItems, showItems, recommendedItems, weekly.data, recent.data, myList, genreItems]);
  const { ratingsMap, ageLimitSetting } = useRatings(combined);
  const rate = item => {
    const result = ratingFor(item, ratingsMap);
    return { ...result, restricted: isRestricted(result.minAge, ageLimitSetting) };
  };
  React.useLayoutEffect(() => {
    const remembered = savedFocus;
    if (!remembered || !root.current || (selected !== 'all' && directory.loading)
        || (remembered.id.startsWith('movies-') && movies.loading)
        || (remembered.id.startsWith('shows-') && series.loading)) return;
    const frame = requestAnimationFrame(() => {
      if (savedFocus !== remembered || !root.current) return;
      const card = root.current.querySelector('[data-home-focus="' + CSS.escape(remembered.id) + '"]');
      if (!card) return;
      card.focus({ preventScroll: true });
      window.dispatchEvent(new CustomEvent('streambert:restore-home-focus', { detail: card }));
      const scroll = root.current.closest('.main');
      if (scroll) scroll.scrollTop = remembered.top;
      const rail = card.closest('.tv-home-rail');
      if (rail) rail.scrollLeft = remembered.left;
      savedFocus = null;
    });
    return () => cancelAnimationFrame(frame);
  }, [selected, directory.loading, movies.loading, series.loading, movieItems, showItems,
    weekly.data, recent.data, myList, continueItems, recommendedItems, genreItems]);

  const updateService = value => {
    setSelected(value);
    store('service', value);
  };
  const updateRegion = value => {
    setRegion(value);
    store('region', value);
    updateService('all');
    setRegionOpen(false);
    if (regionButton.current) {
      window.dispatchEvent(new CustomEvent('streambert:restore-home-focus', { detail: regionButton.current }));
    }
  };
  const pick = (item, state, target, resume) => {
    if (state.restricted) return;
    const key = mediaKey(item);
    const playback = window.streambertPlayback;
    const resumeThroughShow = resume && item.media_type === 'tv' && playback?.hasResume?.(key);
    if (resume && !resumeThroughShow && playback?.resume(key)) return;
    savedFocus = { id: target.dataset.homeFocus,
      top: root.current?.closest('.main')?.scrollTop || 0,
      left: target.closest('.tv-home-rail')?.scrollLeft || 0 };
    onSelect(resumeThroughShow ? { ...item, tvResumeKey: key } : item);
  };
  const shared = { progress, onPick: pick, rating: rate };
  const status = request => request.loading || (service && directory.loading) ? 'Loading…' : request.error ? 'This row couldn’t load.'
    : offline ? 'Unavailable offline.' : 'No titles available.';
  return ui.jsxs('div', { className: 'tv-home', ref: root, children: [
    ui.jsx(HomeRail, { ...shared, id: 'continue', title: 'Continue Watching', items: continueItems,
      message: 'Titles you start will appear here.', resume: true }),
    ui.jsxs('section', { className: 'section tv-home-section', 'aria-labelledby': 'home-heading-services', children: [
      railHeading('services', 'Browse by Service', 'Subscription catalogs'),
      ui.jsxs('div', { className: 'tv-home-services', children: [
        ui.jsxs('div', { className: 'tv-home-filters', 'aria-label': 'Streaming services', children: [
          ui.jsx('button', { className: 'tv-home-chip', 'aria-pressed': all,
            onClick: () => updateService('all'), children: 'All Services' }),
          ...available.map(option => ui.jsx('button', { className: 'tv-home-chip', 'aria-pressed': service === option,
            onClick: () => updateService(option.id), children: option.label }, option.id)),
        ] }),
        ui.jsx('button', { className: 'tv-home-chip tv-home-region', ref: regionButton, 'aria-expanded': regionOpen,
          onClick: () => setRegionOpen(!regionOpen), children: regions[region] + ' ▾' }),
      ] }),
      regionOpen && ui.jsx('div', { className: 'tv-home-filters tv-home-countries', 'aria-label': 'Catalog country',
        children: Object.entries(regions).map(([code, name]) => ui.jsx('button', { className: 'tv-home-chip',
          'aria-pressed': code === region, onClick: () => updateRegion(code), children: name }, code)) }),
      directory.error && ui.jsx('button', { className: 'tv-home-chip', onClick: () => setReload(reload + 1),
        children: 'Retry service list' }),
    ] }),
    all && ui.jsx(HomeRail, { ...shared, id: 'recommended', title: 'Recommended for You', items: recommendedItems }),
    all && ui.jsx(HomeRail, { ...shared, id: 'trending', title: 'Trending This Week', items: weekly.data || [],
      message: weekly.loading ? 'Loading…' : null }),
    ui.jsx(HomeRail, { ...shared, id: 'movies', title: all ? 'Popular Movies' : 'Popular Movies on ' + service.label,
      items: movieItems, message: status(movies) }),
    ui.jsx(HomeRail, { ...shared, id: 'shows', title: all ? 'Popular Shows' : 'Popular Shows on ' + service.label,
      items: showItems, message: status(series) }),
    all && ui.jsx(HomeRail, { ...shared, id: 'recent', title: 'Recently Released', items: recent.data || [],
      message: recent.loading ? 'Loading…' : null }),
    ...genreItems.map(row => ui.jsx(HomeRail, { ...shared, id: row.id,
      title: service ? row.title + ' on ' + service.label : row.title, items: row.items }, row.id)),
    ui.jsx(HomeRail, { ...shared, id: 'watchlist', title: 'My List', items: myList,
      message: 'Save a title to find it here.' }),
    ui.jsx('div', { className: 'tv-home-credits', children: 'Catalog data from TMDB. Streaming availability data provided by JustWatch.' }),
  ] });
}
