(() => {
  if (window.streambertAndroidTV) return;
  const sources = new Set([
    'vsembed.su', 'vidfast.vc', 'player.vidlove.cc', 'embed.vidrift.net',
    'vidnest.fun', 'aether.ist', 'devideosrc.co', 'frembed.uno', 'on.kinohub.vip',
  ]);
  const secrets = new Set(['apikey', 'subdlApiKey', 'wyzieApiKey']);
  let player = null;
  let previousFocus = null;
  let catalogCanGoBack = false;

  function playerAddress(value) {
    try {
      const url = new URL(value);
      return url.protocol === 'https:' && !url.username && !url.password
        && (!url.port || url.port === '443') && sources.has(url.hostname) ? url : null;
    } catch (_) {
      return null;
    }
  }

  function closePlayer() {
    if (!player) return false;
    player.remove();
    player = null;
    if (previousFocus?.isConnected) previousFocus.focus({ preventScroll: true });
    previousFocus = null;
    window.dispatchEvent(new Event('streambert:native-player-closed'));
    return true;
  }

  function openPlayer(value) {
    const url = playerAddress(value);
    closePlayer();
    previousFocus = document.activeElement;
    player = document.createElement('section');
    player.className = 'portable-player';
    player.setAttribute('aria-label', 'Streambert playback');
    const back = document.createElement('button');
    back.type = 'button';
    back.className = 'portable-player-back';
    back.textContent = '‹ Back to Streambert';
    back.addEventListener('click', closePlayer);
    player.append(back);
    if (url) {
      const frame = document.createElement('iframe');
      frame.title = 'Video player';
      frame.setAttribute('sandbox', 'allow-scripts allow-same-origin');
      frame.setAttribute('allow', 'autoplay; encrypted-media');
      frame.tabIndex = 0;
      frame.src = url.href;
      back.addEventListener('keydown', event => {
        if (event.key === 'ArrowDown') {
          event.stopPropagation();
          event.preventDefault();
          frame.focus();
        }
      });
      player.append(frame);
    } else {
      const message = document.createElement('p');
      message.textContent = 'This playback source is unavailable in the TV preview. Go back and try a different source.';
      player.append(message);
    }
    document.body.append(player);
    back.focus({ preventScroll: true });
    return Boolean(url);
  }

  window.streambertAndroidTV = Object.freeze({
    openPlayer,
    closePlayer,
    setCanGoBack(value) { catalogCanGoBack = Boolean(value); },
    getPlatform() { return 'android'; },
    getAppVersion() { return '2.7.1'; },
    getSecret(key) {
      if (!secrets.has(key)) return null;
      try { return localStorage.getItem('streambert-portable-' + key); }
      catch (_) { return null; }
    },
    setSecret(key, value) {
      if (!secrets.has(key)) return;
      try {
        if (value) localStorage.setItem('streambert-portable-' + key, String(value));
        else localStorage.removeItem('streambert-portable-' + key);
      } catch (_) {}
    },
    openExternal() { return false; },
  });

  window.addEventListener('keydown', event => {
    const activeOverlay = player;
    const back = event.key === 'Escape' || event.key === 'GoBack' || event.keyCode === 10009 || event.keyCode === 461;
    if (back && (activeOverlay || catalogCanGoBack)) {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (!closePlayer()) window.dispatchEvent(new Event('streambert:android-back'));
      return;
    }
    if (activeOverlay && (event.key === 'Enter' || event.key.startsWith('Arrow'))) {
      event.stopImmediatePropagation();
      if (event.key === 'ArrowDown') {
        const frame = activeOverlay.querySelector('iframe');
        if (frame) {
          event.preventDefault();
          frame.focus();
        }
      } else if (event.key === 'Enter' && document.activeElement === activeOverlay.firstElementChild) {
        event.preventDefault();
        closePlayer();
      }
    }
  }, true);
})();
