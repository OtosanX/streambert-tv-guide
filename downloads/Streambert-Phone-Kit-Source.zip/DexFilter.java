import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.Opcode;
import com.android.tools.smali.dexlib2.builder.MutableMethodImplementation;
import com.android.tools.smali.dexlib2.builder.instruction.BuilderInstruction35c;
import com.android.tools.smali.dexlib2.builder.instruction.BuilderInstruction10x;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethodParameter;
import com.android.tools.smali.dexlib2.iface.Method;
import com.android.tools.smali.dexlib2.iface.instruction.formats.Instruction35c;
import com.android.tools.smali.dexlib2.iface.reference.MethodReference;
import com.android.tools.smali.dexlib2.immutable.ImmutableClassDef;
import com.android.tools.smali.dexlib2.immutable.ImmutableMethod;
import com.android.tools.smali.dexlib2.immutable.reference.ImmutableMethodReference;
import java.util.ArrayList;
import java.util.List;
import java.io.File;

public class DexFilter {
    public static void main(String[] args) throws Exception {
        String player = "Lcom/truelockmc/streambert/AndroidTVPlayerActivity";
        var original = DexFileFactory.loadDexFile(new File(args[0]), Opcodes.forApi(24));
        var pool = new DexPool(original.getOpcodes());
        int removed = 0;
        for (ClassDef type : original.getClasses()) {
            if (type.getType().equals(player + ";") || type.getType().startsWith(player + "$")) {
                removed++;
            } else {
                pool.internClass(type.getType().equals("Lcom/truelockmc/streambert/MainActivity;")
                        ? wireCatalog(type) : type);
            }
        }
        if (removed != 4) throw new IllegalStateException("Unexpected original player class count: " + removed);
        pool.writeTo(new FileDataStore(new File(args[1])));
    }

    private static ClassDef wireCatalog(ClassDef type) {
        List<Method> methods = new ArrayList<>();
        boolean attached = false;
        for (Method method : type.getMethods()) {
            if (!method.getName().equals("onCreate")) {
                methods.add(method);
                continue;
            }
            var code = new MutableMethodImplementation(method.getImplementation());
            for (int index = 0; index < code.getInstructions().size(); index++) {
                if (!(code.getInstructions().get(index) instanceof Instruction35c call)
                        || !(call.getReference() instanceof MethodReference reference)
                        || !reference.getDefiningClass().equals("Landroid/webkit/WebView;")
                        || !reference.getName().equals("loadUrl")) continue;
                var attach = new ImmutableMethodReference("Lcom/truelockmc/streambert/CatalogPlayback;",
                        "attach", List.of("Landroid/webkit/WebView;"), "V");
                code.addInstruction(index, new BuilderInstruction35c(
                        Opcode.INVOKE_STATIC, 1, call.getRegisterC(), 0, 0, 0, 0, attach));
                attached = true;
                break;
            }
            methods.add(new ImmutableMethod(type.getType(), method.getName(), method.getParameters(),
                    method.getReturnType(), method.getAccessFlags(), method.getAnnotations(),
                    method.getHiddenApiRestrictions(), code));
        }
        if (!attached) throw new IllegalStateException("Catalog WebView attachment point missing");
        var newIntent = new MutableMethodImplementation(2);
        String intent = "Landroid/content/Intent;";
        newIntent.addInstruction(new BuilderInstruction35c(Opcode.INVOKE_SUPER, 2, 0, 1, 0, 0, 0,
                new ImmutableMethodReference("Landroid/app/Activity;", "onNewIntent", List.of(intent), "V")));
        newIntent.addInstruction(new BuilderInstruction35c(Opcode.INVOKE_STATIC, 2, 0, 1, 0, 0, 0,
                new ImmutableMethodReference("Lcom/truelockmc/streambert/CatalogPlayback;", "launch",
                        List.of("Landroid/app/Activity;", intent), "V")));
        newIntent.addInstruction(new BuilderInstruction10x(Opcode.RETURN_VOID));
        methods.add(new ImmutableMethod(type.getType(), "onNewIntent",
                List.of(new ImmutableMethodParameter(intent, java.util.Set.of(), "intent")), "V", 4,
                java.util.Set.of(), java.util.Set.of(), newIntent));
        return new ImmutableClassDef(type.getType(), type.getAccessFlags(), type.getSuperclass(),
                type.getInterfaces(), type.getSourceFile(), type.getAnnotations(), type.getFields(), methods);
    }
}
