import assert from 'node:assert/strict';
import { continueQueue } from './tv-continue.js';

const older = { media_type: 'tv', id: 12, season: 2, episode: 7, watchedAt: 1 };
const newer = { media_type: 'tv', id: 12, season: 2, episode: 8, watchedAt: 2 };
const finished = { media_type: 'movie', id: 50, watchedAt: 3 };
const unfinished = { media_type: 'movie', id: 51, watchedAt: 4 };
const history = [unfinished, finished, newer, older];
const snapshot = structuredClone(history);
assert.deepEqual(continueQueue([older, newer, newer, finished, unfinished], history, { movie_50: 100 }, {}),
  [newer, unfinished]);
assert.deepEqual(continueQueue([older, finished, unfinished], history, {}, { movie_50: true }), [unfinished]);
assert.deepEqual(continueQueue([newer, older], history, { tv_12_s2e8: 100 }, {}), []);
assert.deepEqual(history, snapshot);
console.log('PASS one episode per series, completed titles removed from Continue Watching, history preserved');
