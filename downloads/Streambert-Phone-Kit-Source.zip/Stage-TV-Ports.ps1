param([Parameter(Mandatory)][string]$Apk)
$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $true
$stage = Join-Path $PSScriptRoot 'tv-ports'
$catalog = Join-Path $stage 'catalog'
$webPackage = Join-Path $catalog 'assets/public'
New-Item -ItemType Directory -Force $catalog | Out-Null
tar -xf $Apk -C $catalog assets/public
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'portable-tv.js') -Destination $webPackage
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'portable-tv.css') -Destination $webPackage
Copy-Item -LiteralPath (Join-Path $webPackage 'sized/128x128.png') -Destination (Join-Path $webPackage 'port-icon.png')
$htmlFile = Join-Path $webPackage 'index.html'
$html = Get-Content -Raw $htmlFile
if (!$html.Contains('<head>')) { throw 'Unknown catalog entry page' }
$framePolicy = "object-src 'none'; base-uri 'none'; frame-src https://vsembed.su https://vidfast.vc https://player.vidlove.cc https://embed.vidrift.net https://vidnest.fun https://aether.ist https://devideosrc.co https://frembed.uno https://on.kinohub.vip"
$html = $html.Replace('<head>', '<head>' + [Environment]::NewLine +
    ('<meta http-equiv="Content-Security-Policy" content="' + $framePolicy + '">') +
    '<link rel="stylesheet" href="./portable-tv.css"><script src="./portable-tv.js"></script>')
[IO.File]::WriteAllText($htmlFile, $html)
foreach ($platform in @('Samsung-Tizen','LG-webOS','WebView-preview')) {
    $destination = Join-Path $stage $platform
    New-Item -ItemType Directory -Force $destination | Out-Null
    Get-ChildItem -LiteralPath $webPackage | Copy-Item -Destination $destination -Recurse -Force
}
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'portable-config.xml') -Destination (Join-Path $stage 'Samsung-Tizen/config.xml')
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'portable-appinfo.json') -Destination (Join-Path $stage 'LG-webOS/appinfo.json')
