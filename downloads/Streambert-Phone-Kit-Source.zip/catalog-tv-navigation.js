function ae(element) {
  if (!(element instanceof HTMLElement)
    || element.closest('[data-gamepad-ignore], [inert], [aria-hidden="true"]')
    || element.matches('.carousel-btn, .carousel-dot, .carousel-item:not(.carousel-item--active)')
    || element.matches(':disabled, [aria-disabled="true"], input[type="hidden"]')) return false;
  const style = getComputedStyle(element);
  if (style.visibility !== 'visible' || style.display === 'none'
    || (element.offsetParent === null && style.position !== 'fixed')) return false;
  const rect = element.getBoundingClientRect();
  return rect.width > 0 && rect.height > 0;
}

function ge(candidates) {
  const visible = candidates.filter(element => {
    const rect = element.getBoundingClientRect();
    return rect.bottom > 0 && rect.top < innerHeight
      && rect.right > 0 && rect.left < innerWidth;
  });
  return visible.reduce((best, element) => {
    const position = item => {
      const rect = item.getBoundingClientRect();
      return 2 * Math.max(0, rect.top) + Math.max(0, rect.left);
    };
    return !best || position(element) < position(best) ? element : best;
  }, null) || candidates[0] || null;
}

function be(direction) {
  const candidates = de();
  if (!candidates.length) return;
  const current = he();
  if (!candidates.includes(current)) {
    pe(ge(candidates));
    return;
  }
  const [dx, dy] = xe[direction];
  const origin = current.getBoundingClientRect();
  const sidebar = current.closest('.sidebar');
  const carousel = current.closest('.carousel-section');
  if (dx && carousel && current.matches('.carousel-item--active')) {
    carousel.querySelector(dx > 0 ? '.carousel-btn--right' : '.carousel-btn--left')?.click();
    return;
  }
  const cardSection = current.matches('.card') ? current.closest('.section') : null;
  const homeRail = current.closest('.tv-home-rail, .tv-home-services, .tv-home-countries');
  if (dx && homeRail) {
    const row = [...homeRail.querySelectorAll('button')].filter(ae);
    const neighbor = row[row.indexOf(current) + dx];
    if (neighbor) pe(neighbor);
    return;
  }
  const searchCard = current.matches('.tv-search-result');
  let best = null;
  let bestScore = Infinity;

  for (const candidate of candidates) {
    if (candidate === current) continue;
    if (dy && candidate.closest('.sidebar') !== sidebar) continue;
    const nextCarousel = candidate.closest('.carousel-section');
    if (dy && nextCarousel) {
      if (nextCarousel === carousel || !candidate.matches('.carousel-item--active')) continue;
    }
    const rect = candidate.getBoundingClientRect();
    if (dx && searchCard && (!candidate.matches('.tv-search-result')
      || rect.bottom <= origin.top || rect.top >= origin.bottom)) continue;
    if (dx && cardSection && (candidate.closest('.section') !== cardSection
      || rect.bottom <= origin.top || rect.top >= origin.bottom)) continue;
    const deltaX = (rect.left + rect.right - origin.left - origin.right) / 2;
    const deltaY = (rect.top + rect.bottom - origin.top - origin.bottom) / 2;
    const forward = deltaX * dx + deltaY * dy;
    if (forward <= 2) continue;
    const cross = Math.abs(deltaX * dy - deltaY * dx);
    const score = forward + cross * (dy ? 1.25 : 2.5);
    if (score < bestScore) {
      best = candidate;
      bestScore = score;
    }
  }
  if (best) pe(best);
}

function bindAndroidBack(bridge, isHome, hasHistory, hasModal, goBack, closeModals) {
  const restore = event => {
    if (event.detail instanceof HTMLElement && event.detail.isConnected) pe(event.detail, { scroll: false });
  };
  const mainFocus = () => {
    const current = he() || document.activeElement;
    return isHome && Boolean(current?.closest('.main'));
  };
  const update = () => bridge.setCanGoBack?.(hasHistory || !isHome || hasModal || mainFocus());
  const back = () => {
    if (me()) return;
    if (hasModal) {
      closeModals();
      return;
    }
    if (mainFocus()) {
      const sidebar = document.querySelector('.sidebar .sidebar-btn.active, .sidebar .sidebar-btn');
      const active = document.querySelector('.sidebar .sidebar-btn.active');
      if (active || sidebar) {
        pe(active || sidebar);
        return;
      }
    }
    goBack();
  };
  window.addEventListener('streambert:tv-focus', update);
  window.addEventListener('streambert:android-back', back);
  window.addEventListener('streambert:restore-home-focus', restore);
  document.addEventListener('focusin', update);
  update();
  return () => {
    window.removeEventListener('streambert:tv-focus', update);
    window.removeEventListener('streambert:android-back', back);
    window.removeEventListener('streambert:restore-home-focus', restore);
    document.removeEventListener('focusin', update);
  };
}
