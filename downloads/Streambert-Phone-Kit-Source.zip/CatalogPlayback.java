package com.truelockmc.streambert;

import android.app.Activity;
import android.content.ContentUris;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.tv.TvContract.WatchNextPrograms;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;

import org.json.JSONObject;
import org.json.JSONException;

import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public final class CatalogPlayback {
    private static WeakReference<WebView> catalog = new WeakReference<>(null);
    private static final String PLAY_NEXT = "com.truelockmc.streambert.PLAY_NEXT";
    private static final Executor provider = Executors.newSingleThreadExecutor();
    private static volatile JSONObject preparedItem;

    public static void attach(WebView view) {
        catalog = new WeakReference<>(view);
        preparedItem = null;
        view.addJavascriptInterface(new CatalogPlayback(), "streambertPlayback");
        if (view.getContext() instanceof Activity) {
            Activity activity = (Activity) view.getContext();
            view.post(() -> launch(activity, activity.getIntent()));
        }
    }

    @JavascriptInterface
    public void prepare(String detail) {
        preparedItem = parse(detail);
    }

    @JavascriptInterface
    public void pasteTmdbToken() {
        WebView view = catalog.get();
        if (view == null) return;
        view.post(() -> {
            if (catalog.get() != view || !view.hasWindowFocus()) return;
            ClipboardManager clipboard = (ClipboardManager) view.getContext().getSystemService(Context.CLIPBOARD_SERVICE);
            String token = null;
            try {
                ClipData clip = clipboard == null ? null : clipboard.getPrimaryClip();
                if (clip != null && clip.getItemCount() > 0) {
                    CharSequence text = clip.getItemAt(0).getText();
                    if (text != null && text.length() < 4096) {
                        String value = text.toString().trim().replaceFirst("(?i)^Bearer\\s+", "").replaceAll("\\s+", "");
                        if (value.matches("[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+")) token = value;
                    }
                }
            } catch (SecurityException ignored) {
            }
            view.evaluateJavascript("window.dispatchEvent(new CustomEvent('streambert:clipboard-token',{detail:"
                    + (token == null ? "null" : JSONObject.quote(token)) + "}))", null);
        });
    }

    private static JSONObject parse(String detail) {
        if (detail == null || detail.length() > 4096) return null;
        try {
            JSONObject item = new JSONObject(detail);
            return validKey(item.optString("key")) ? item : null;
        } catch (JSONException ignored) {
            return null;
        }
    }

    private static boolean validKey(String key) {
        return key != null && key.matches("(?:movie_[0-9]+|tv_[0-9]+_s[0-9]+e[0-9]+)");
    }

    static JSONObject preparedItem() {
        return preparedItem;
    }

    static void requestAutoplay(String key, ValueCallback<String> callback) {
        WebView view = catalog.get();
        if (view == null) {
            callback.onReceiveValue("0");
            return;
        }
        view.evaluateJavascript("(() => { const detail = {key:" + JSONObject.quote(key)
                + ",delay:0}; window.dispatchEvent(new CustomEvent('streambert:tv-autoplay-check',{detail}));"
                + "return detail.delay; })()", callback);
    }

    static void playNextEpisode(String key) {
        WebView view = catalog.get();
        if (view != null) view.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('streambert:tv-autoplay-next',{detail:"
                        + JSONObject.quote(key) + "}))", null);
    }

    public static void launch(Activity activity, Intent incoming) {
        if (incoming == null || !PLAY_NEXT.equals(incoming.getAction())) return;
        if (openStored(activity, incoming.getStringExtra("key"))) incoming.setAction(Intent.ACTION_MAIN);
    }

    @JavascriptInterface
    public boolean hasResume(String key) {
        WebView view = catalog.get();
        if (!validKey(key) || view == null || !(view.getContext() instanceof Activity)) return false;
        Activity activity = (Activity) view.getContext();
        return getResumeTime(activity, key) > 0 && savedIntent(activity, key) != null;
    }

    @JavascriptInterface
    public boolean resume(String key) {
        if (!hasResume(key)) return false;
        WebView view = catalog.get();
        if (view == null || !(view.getContext() instanceof Activity)) return false;
        Activity activity = (Activity) view.getContext();
        return view.post(() -> openStored(activity, key));
    }

    private static Intent savedIntent(Activity activity, String key) {
        if (!validKey(key)) return null;
        SharedPreferences prefs = storage(activity);
        JSONObject item = parse(prefs.getString("item:" + key, null));
        String url = prefs.getString("url:" + key, "");
        Uri uri = Uri.parse(url);
        if (item == null || uri.getHost() == null
                || !("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))) return null;
        Intent player = new Intent(activity, AndroidTVPlayerActivity.class);
        player.putExtra("streambert.player.url", url);
        player.putExtra("streambert.player.userAgent", prefs.getString("agent:" + key, ""));
        return player;
    }

    private static boolean openStored(Activity activity, String key) {
        Intent player = savedIntent(activity, key);
        if (player == null || activity.isFinishing()) return false;
        preparedItem = parse(storage(activity).getString("item:" + key, null));
        activity.startActivity(player);
        return true;
    }

    private static SharedPreferences storage(Context context) {
        return context.getSharedPreferences("streambert_playback_time", Context.MODE_PRIVATE);
    }

    static float getResumeTime(Context context, String key) {
        return key == null ? 0 : storage(context).getFloat(key, 0);
    }

    static void record(Context context, JSONObject item, String url, String agent, double seconds, double duration,
                       boolean publish) {
        String key = item.optString("key");
        if (!validKey(key) || !Double.isFinite(seconds) || !Double.isFinite(duration)
                || seconds < 15 || duration < 120 || seconds > duration) return;
        double percent = 100 * seconds / duration;
        boolean completed = percent >= 98;
        double displayedProgress = completed ? 100 : percent;
        SharedPreferences.Editor playback = storage(context).edit().putFloat(key, completed ? 0 : (float) seconds);
        if (completed) {
            playback.remove("item:" + key).remove("url:" + key).remove("agent:" + key);
        } else {
            playback.putString("item:" + key, item.toString()).putString("url:" + key, url)
                    .putString("agent:" + key, agent);
        }
        playback.apply();
        if (publish && Build.VERSION.SDK_INT >= 26 && seconds >= 30
                && !context.getPackageManager().hasSystemFeature("amazon.hardware.fire_tv")) {
            Context app = context.getApplicationContext();
            provider.execute(() -> updatePlayNext(app, item, seconds, duration, completed));
        }
        WebView view = catalog.get();
        if (view == null) return;
        view.evaluateJavascript("window.dispatchEvent(new CustomEvent('streambert:tv-progress',{detail:{key:"
                + JSONObject.quote(key) + ",percent:" + displayedProgress + "}}))", null);
    }

    private static void updatePlayNext(Context context, JSONObject item, double seconds, double duration, boolean completed) {
        String key = item.optString("key");
        String title = item.optString("title", "");
        if (title.isEmpty() || "null".equals(title)) return;
        SharedPreferences prefs = storage(context);
        long rowId = prefs.getLong("play-next:" + key, -1);
        ContentResolver resolver = context.getContentResolver();
        try {
            if (completed) {
                if (rowId >= 0) resolver.delete(ContentUris.withAppendedId(WatchNextPrograms.CONTENT_URI, rowId), null, null);
                prefs.edit().remove("play-next:" + key).apply();
                return;
            }
            ContentValues values = new ContentValues();
            boolean episode = key.startsWith("tv_");
            values.put(WatchNextPrograms.COLUMN_WATCH_NEXT_TYPE, WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE);
            values.put(WatchNextPrograms.COLUMN_TYPE, episode ? WatchNextPrograms.TYPE_TV_EPISODE : WatchNextPrograms.TYPE_MOVIE);
            values.put(WatchNextPrograms.COLUMN_INTERNAL_PROVIDER_ID, key);
            values.put(WatchNextPrograms.COLUMN_CONTENT_ID, key);
            values.put(WatchNextPrograms.COLUMN_TITLE, title);
            values.put(WatchNextPrograms.COLUMN_LAST_ENGAGEMENT_TIME_UTC_MILLIS, System.currentTimeMillis());
            values.put(WatchNextPrograms.COLUMN_LAST_PLAYBACK_POSITION_MILLIS, (int) Math.min(Integer.MAX_VALUE, seconds * 1000));
            values.put(WatchNextPrograms.COLUMN_DURATION_MILLIS, (int) Math.min(Integer.MAX_VALUE, duration * 1000));
            String poster = item.optString("poster");
            if (poster.startsWith("/")) {
                values.put(WatchNextPrograms.COLUMN_POSTER_ART_URI, "https://image.tmdb.org/t/p/w342" + poster);
            }
            if (episode) {
                values.put(WatchNextPrograms.COLUMN_SERIES_ID, key.substring(0, key.indexOf("_s")));
                values.put(WatchNextPrograms.COLUMN_SEASON_DISPLAY_NUMBER, item.optString("season"));
                values.put(WatchNextPrograms.COLUMN_EPISODE_DISPLAY_NUMBER, item.optString("episode"));
                if (!item.isNull("episodeTitle")) values.put(WatchNextPrograms.COLUMN_EPISODE_TITLE, item.optString("episodeTitle"));
            }
            Intent deepLink = new Intent(PLAY_NEXT).setPackage(context.getPackageName())
                    .addCategory(Intent.CATEGORY_BROWSABLE)
                    .putExtra("key", key);
            values.put(WatchNextPrograms.COLUMN_INTENT_URI, deepLink.toUri(Intent.URI_INTENT_SCHEME));
            if (rowId >= 0) {
                int changed = resolver.update(ContentUris.withAppendedId(WatchNextPrograms.CONTENT_URI, rowId), values, null, null);
                if (changed == 0) Log.i("StreambertPlayNext", "Previously published row was removed");
            } else {
                Uri inserted = resolver.insert(WatchNextPrograms.CONTENT_URI, values);
                if (inserted != null) prefs.edit().putLong("play-next:" + key, ContentUris.parseId(inserted)).apply();
            }
        } catch (RuntimeException error) {
            Log.w("StreambertPlayNext", "Unable to update Play Next", error);
        }
    }
}
