# Streambert Android TV player patch

This patch targets the Android conversion in the supplied Streambert 2.7.1 APK. The public upstream repository at commit `270d5fa9fec9a846195b2e08df45c2d939863b64` contains the Electron app. The APK contains a separate Android wrapper and bundled web assets.

- `AndroidTVPlayerActivity.java` supplies the replacement native playback Activity.
- `streambert-tv-player.js` adds player focus, scrolling, HTML5 media shortcuts, and targeted overlay hiding.
- `catalog-tv-navigation.js` patches the bundled catalog so Up and Down move between rows and Left and Right browse within the selected Home category. The build disables timed carousel rotation and hides the onscreen carousel arrows.
- `tv-search.js` and `tv-search.css` provide the full-screen TV search grid, single result activation and return-to-result focus.
- `tv-home.js` and `tv-home.css` provide the dark Home layout with region and service filters, recommendations based on recent watch history, six genre rows, and direct resume for tracked players.
- `tv-continue.js` shows one recent episode per series and excludes completed titles from the Home queue without modifying history.
- `tv-autoplay.js` uses the catalog’s next-episode settings when the regular Android TV player reports that a video ended. The player needs access to the video’s end event. The next episode must have aired and be listed in the same season.
- `tv-focus.css` defines the shared focus outline for the catalog and both playback layouts.
- `tv-setup.js`, `tv-setup.css`, and `tmdb-setup-qr.png` provide the TV onboarding screen. Its QR points to TMDB's API settings and never contains an access token.
- `Stage-TV-Ports.ps1` exports the public catalog assets and the portable player adapter for the TV developer previews.
- `CatalogPlayback.java` shares progress with the local catalog, remembers resume positions, and publishes unfinished items to Android TV's Play Next provider. The player can read position and quality only when the provider exposes the video or player API in an accessible frame.
- `ManifestPermission.java` adds the TV provider permission and the Play Next deep-link intent filter to the packaged manifest.
- `launcher-streambert-play-next.patch` adds Streambert to the existing Shield launcher's Play Next allowlist. Apply it from the root of the launcher repository and rebuild with the key used on the Shield.
- `streambert-ad-hosts.txt` contains the playback request denylist, including a subset of the public desktop app's ad host rules.
- `DexFilter.java` removes the old player Activity and its companion classes. `MainActivity.java` is a compile-time stub excluded from the final package. The actual MainActivity and the catalog bundle come from the supplied APK.
- `player-test.html` is a local Chrome fixture. Open it beside the player script and check that all results say PASS.

## Rebuild

Use PowerShell 7, JDK 21, and an Android SDK with Build Tools 36.0.0, Platform 34, and the command-line tools libraries containing smali-dexlib2 and Guava.

```powershell
./Build-TV.ps1 -OriginalApk 'C:/path/to/original.apk' -Sdk 'C:/path/to/android-sdk' -JavaHome 'C:/path/to/jdk-21' -OutputApk 'C:/path/to/Streambert-Android-TV-anime-continue-fix.apk' -RedesignHome
```

The script builds, aligns, signs and verifies the APK. It creates a new debug keystore under `build/` on first use. Keep that keystore if you plan to install future builds over this build. To reuse a compatible existing Android debug keystore, pass it with `-KeyStore`.
