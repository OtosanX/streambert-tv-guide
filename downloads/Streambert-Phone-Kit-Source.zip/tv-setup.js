import { r as React, I as ui } from './movie-tRBw6X1o.js';

const instructions = [
  'Scan the QR code with your phone camera. Sign in to The Movie Database or create an account.',
  'In API settings, request an API key if you do not already have one.',
  'Copy the long API Read Access Token and enter it below. It is different from the short API Key.',
];
const qrImage = new URL('../tmdb-setup-qr.png', import.meta.url).href;
const cleanToken = value => String(value || '').trim().replace(/^Bearer\s+/i, '').replace(/\s+/g, '');
const isReadToken = token => /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(token) && token.length < 4096;

export default function TvSetup({ onSave }) {
  const [value, setValue] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [message, setMessage] = React.useState('');
  const mounted = React.useRef(true);
  const checking = React.useRef(false);
  const receive = raw => {
    const token = cleanToken(raw);
    if (!isReadToken(token)) {
      setMessage('No TMDB read token was found in the TV clipboard. Paste it using your phone’s remote keyboard or type it here.');
      return;
    }
    setValue(token);
    setMessage('Token pasted. Select Save and continue.');
  };

  React.useEffect(() => {
    mounted.current = true;
    const listener = event => receive(event.detail);
    window.addEventListener('streambert:clipboard-token', listener);
    return () => {
      mounted.current = false;
      window.removeEventListener('streambert:clipboard-token', listener);
    };
  }, []);

  async function paste() {
    if (window.streambertPlayback?.pasteTmdbToken) {
      window.streambertPlayback.pasteTmdbToken();
      return;
    }
    try { receive(await navigator.clipboard.readText()); }
    catch (_) { receive(null); }
  }

  async function save(event) {
    event.preventDefault();
    if (checking.current) return;
    const token = cleanToken(value);
    if (!isReadToken(token)) {
      setMessage('Copy the long API Read Access Token from TMDB’s API settings.');
      return;
    }
    checking.current = true;
    setBusy(true);
    setMessage('Checking the token…');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const response = await fetch('https://api.themoviedb.org/3/configuration', {
        headers: { Authorization: 'Bearer ' + token },
        signal: controller.signal,
      });
      if (!mounted.current) return;
      if (response.ok) onSave(token);
      else setMessage(response.status === 401 || response.status === 403
        ? 'TMDB didn’t accept that token. Check that you copied the API Read Access Token.'
        : 'TMDB couldn’t check the token right now. Try again in a moment.');
    } catch (_) {
      if (mounted.current) setMessage('Couldn’t reach TMDB. Check the TV’s internet connection and try again.');
    } finally {
      clearTimeout(timeout);
      checking.current = false;
      if (mounted.current) setBusy(false);
    }
  }

  return ui.jsx('main', { className: 'tv-setup-overlay', children: ui.jsxs('section', {
    className: 'tv-setup-panel', 'aria-labelledby': 'tv-setup-title', children: [
      ui.jsx('h1', { id: 'tv-setup-title', children: 'Set up Streambert' }),
      ui.jsx('p', { children: 'Connect TMDB to load titles, artwork, and search results.' }),
      ui.jsxs('div', { className: 'tv-setup-instructions', children: [
        ui.jsxs('figure', { children: [
          ui.jsx('img', { src: qrImage, alt: 'Scan to open TMDB API settings', width: 240, height: 240 }),
          ui.jsx('figcaption', { children: 'themoviedb.org/settings/api' }),
        ] }),
        ui.jsxs('div', { children: [
          ui.jsx('ol', { children: instructions.map(step => ui.jsx('li', { children: step }, step)) }),
          ui.jsx('p', { className: 'tv-setup-hint',
            children: 'If TMDB’s form is hard to use on your phone, try desktop view or open the page on a computer.' }),
        ] }),
      ] }),
      ui.jsxs('form', { onSubmit: save, children: [
        ui.jsx('label', { htmlFor: 'tv-setup-token', children: 'TMDB API Read Access Token' }),
        ui.jsx('input', { id: 'tv-setup-token', type: 'password', autoComplete: 'off', autoCapitalize: 'none',
          spellCheck: false, maxLength: 4096, value, disabled: busy,
          onChange: event => { setValue(event.target.value); setMessage(''); },
          placeholder: 'Paste or enter your token' }),
        ui.jsx('p', { className: 'tv-setup-hint',
          children: 'Using atvTools? Select the token field on the TV, then paste the token with atvTools’ phone keyboard.' }),
        ui.jsxs('div', { className: 'tv-setup-actions', children: [
          ui.jsx('button', { type: 'button', onClick: paste, disabled: busy, children: 'Paste from TV clipboard' }),
          ui.jsx('button', { type: 'submit', disabled: !value.trim() || busy,
            children: busy ? 'Checking…' : 'Save and continue' }),
        ] }),
        ui.jsx('p', { className: 'tv-setup-status', role: 'status', children: message }),
      ] }),
    ],
  }) });
}
