import * as React from 'react';
import { View } from 'react-native';
import { WebView } from '@amazon-devices/webview';

export const App = () => (
  <View style={{ flex: 1, backgroundColor: '#0b0d10' }}>
    <WebView
      style={{ flex: 1, backgroundColor: '#0b0d10' }}
      source={{ uri: 'file:///pkg/assets/streambert/index.html' }}
      javaScriptEnabled
      hasTVPreferredFocus
      allowSystemKeyEvents
      mediaPlaybackRequiresUserAction={false}
    />
  </View>
);

export default App;
