package com.truelockmc.streambert;

final class MainActivity {
    static void notifyPlayerClosed() {
        throw new AssertionError("Compile-time stub");
    }
}
