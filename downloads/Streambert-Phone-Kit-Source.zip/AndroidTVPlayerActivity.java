package com.truelockmc.streambert;

import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;

public final class AndroidTVPlayerActivity extends Activity {
    private static WeakReference<AndroidTVPlayerActivity> current = new WeakReference<>(null);
    private Uri source;
    private WebView web;
    private FrameLayout root;
    private FrameLayout stage;
    private View fullscreen;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private TextView cursor;
    private String script;
    private String[] adHosts;
    private boolean pointerMode;
    private boolean backPending;
    private float pointerX;
    private float pointerY;
    private int selectKey = KeyEvent.KEYCODE_UNKNOWN;
    private long selectDownTime;
    private JSONObject mediaItem;
    private String mediaUserAgent;
    private float resumeAt;
    private double lastPosition;
    private double lastDuration;
    private long playbackGeneration;
    private boolean playbackActive;
    private boolean autoplayChecked;
    private boolean autoplayCancelled;
    private boolean advancingEpisode;
    private final Runnable advanceEpisode = () -> {
        if (!playbackActive || autoplayCancelled || backPending || isFinishing()) return;
        advancingEpisode = true;
        finish();
    };
    private final Handler playbackHandler = new Handler(Looper.getMainLooper());
    private final Runnable playbackTick = new Runnable() {
        @Override
        public void run() {
            samplePlayback(false);
            if (web != null) playbackHandler.postDelayed(this, 5000);
        }
    };

    static void closeCurrent() {
        AndroidTVPlayerActivity activity = current.get();
        if (activity != null) activity.runOnUiThread(activity::finish);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = new WeakReference<>(this);
        source = Uri.parse(getIntent().getStringExtra("streambert.player.url") == null
                ? "" : getIntent().getStringExtra("streambert.player.url"));
        if (!isWebUrl(source)) {
            finish();
            return;
        }
        script = readAsset("streambert-tv-player.js");
        mediaItem = CatalogPlayback.preparedItem();
        if (mediaItem != null && mediaItem.optBoolean("trackProgress", true)) {
            resumeAt = CatalogPlayback.getResumeTime(this, mediaItem.optString("key"));
        }
        adHosts = readAsset("streambert-ad-hosts.txt").split("\\s+");
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        stage = new FrameLayout(this);
        root.addView(stage, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        hideSystemBars();
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setFocusableInTouchMode(true);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        stage.addView(web, new FrameLayout.LayoutParams(-1, -1));
        cursor = new TextView(this);
        cursor.setText("⊕");
        cursor.setTextColor(Color.WHITE);
        cursor.setTextSize(24);
        cursor.setShadowLayer(3, 1, 1, Color.BLACK);
        cursor.setVisibility(View.INVISIBLE);
        cursor.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        stage.addView(cursor, new FrameLayout.LayoutParams(-2, -2));

        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        mediaUserAgent = getIntent().getStringExtra("streambert.player.userAgent");
        if (mediaUserAgent != null && !mediaUserAgent.isEmpty()) settings.setUserAgentString(mediaUserAgent);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.setWebViewClient(new PlayerClient());
        web.setWebChromeClient(new PlayerChrome());
        web.loadUrl(source.toString());
        web.requestFocus();
    }

    private String readAsset(String name) {
        try (InputStream input = getAssets().open(name);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            return new String(output.toByteArray(), StandardCharsets.UTF_8);
        } catch (java.io.IOException error) {
            throw new IllegalStateException("Missing player asset " + name, error);
        }
    }

    private static boolean isWebUrl(Uri uri) {
        return uri.getHost() != null &&
                ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()));
    }

    private static int port(Uri uri) {
        if (uri.getPort() != -1) return uri.getPort();
        return "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80;
    }

    private static String path(Uri uri) {
        String value = uri.getEncodedPath();
        if (value == null || value.isEmpty()) return "/";
        return value.length() > 1 && value.endsWith("/") ? value.substring(0, value.length() - 1) : value;
    }

    private boolean isSource(Uri uri) {
        return isWebUrl(uri) && source.getScheme().equalsIgnoreCase(uri.getScheme())
                && source.getHost().equalsIgnoreCase(uri.getHost()) && port(source) == port(uri)
                && path(source).equals(path(uri));
    }

    private boolean isAd(Uri uri) {
        String host = uri.getHost();
        if (host == null) return false;
        host = host.toLowerCase(java.util.Locale.ROOT);
        if (host.endsWith(".")) host = host.substring(0, host.length() - 1);
        for (String blocked : adHosts) {
            if (!blocked.isEmpty() && (host.equals(blocked) || host.endsWith("." + blocked))) return true;
        }
        return false;
    }

    private Uri animeAudioDestination(String mode) {
        if (!"sub".equals(mode) && !"dub".equals(mode)) return null;
        if (!"https".equalsIgnoreCase(source.getScheme()) || !"vidnest.fun".equalsIgnoreCase(source.getHost())
                || port(source) != 443) return null;
        String currentPath = path(source);
        if (!currentPath.matches("/anime/[0-9]+/[0-9]+/(sub|dub)") || currentPath.endsWith("/" + mode)) return null;
        return source.buildUpon().encodedPath(currentPath.substring(0, currentPath.lastIndexOf('/') + 1) + mode).build();
    }

    private void switchAnimeAudio(Uri destination) {
        Uri current = source;
        samplePlayback(false, () -> {
            if (web == null || source != current || isFinishing() || backPending) return;
            resumeAt = Math.max(resumeAt, (float) lastPosition);
            source = destination;
            web.loadUrl(destination.toString());
        });
    }

    private class PlayerClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri uri = request.getUrl();
            if (request.isForMainFrame() && request.hasGesture()) {
                Uri destination = animeAudioDestination(uri.getLastPathSegment());
                if (uri.equals(destination)) {
                    switchAnimeAudio(destination);
                    return true;
                }
            }
            return isAd(uri) || (request.isForMainFrame() ? !isSource(uri)
                    : !isWebUrl(uri) && !"about:blank".equals(uri.toString()));
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (isAd(request.getUrl()) || (request.isForMainFrame() && !isSource(request.getUrl()))) {
                return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked",
                        java.util.Collections.emptyMap(), new java.io.ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageCommitVisible(WebView view, String url) {
            install(view, url);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            install(view, url);
        }

        private void install(WebView view, String url) {
            if (web == view && isSource(Uri.parse(url))) view.evaluateJavascript(script, null);
        }
    }

    private class PlayerChrome extends WebChromeClient {
        @Override
        public boolean onCreateWindow(WebView view, boolean dialog, boolean userGesture, Message result) {
            return false;
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
            result.cancel();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView view, String url, String message, String value, JsPromptResult result) {
            result.cancel();
            return true;
        }

        @Override
        public boolean onJsBeforeUnload(WebView view, String url, String message, JsResult result) {
            result.confirm();
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (fullscreen != null || web == null) {
                callback.onCustomViewHidden();
                return;
            }
            fullscreen = view;
            fullscreenCallback = callback;
            stage.addView(view, 1, new FrameLayout.LayoutParams(-1, -1));
            web.setVisibility(View.INVISIBLE);
            setPointerMode(false);
            view.requestFocus();
            hideSystemBars();
        }

        @Override
        public void onHideCustomView() {
            leaveFullscreen();
        }
    }

    private void leaveFullscreen() {
        if (fullscreen == null) return;
        stage.removeView(fullscreen);
        fullscreen = null;
        WebChromeClient.CustomViewCallback callback = fullscreenCallback;
        fullscreenCallback = null;
        setPointerMode(false);
        web.setVisibility(View.VISIBLE);
        web.requestFocus();
        callback.onCustomViewHidden();
        hideSystemBars();
    }

    private void hideSystemBars() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                controller.hide(WindowInsets.Type.systemBars());
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(5894);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused && root != null) hideSystemBars();
        if (!focused) selectKey = KeyEvent.KEYCODE_UNKNOWN;
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (web == null) return super.dispatchKeyEvent(event);
        int code = event.getKeyCode();
        boolean down = event.getAction() == KeyEvent.ACTION_DOWN;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_BUTTON_A:
                if (down && event.getRepeatCount() == 0) {
                    selectKey = code;
                    selectDownTime = event.getEventTime();
                } else if (!down && selectKey == code) {
                    selectKey = KeyEvent.KEYCODE_UNKNOWN;
                    if (event.isCanceled()) return true;
                    if (event.getEventTime() - selectDownTime >= 550) setPointerMode(!pointerMode);
                    else if (pointerMode) tap();
                    else pageKey("Enter", event);
                }
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                if (down) {
                    if (pointerMode) movePointer(code);
                    else pageKey(arrow(code), event);
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (down && event.getRepeatCount() == 0) pageKey(KeyEvent.keyCodeToString(code), event);
                return true;
            default:
                return super.dispatchKeyEvent(event);
        }
    }

    private String arrow(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return "ArrowUp";
            case KeyEvent.KEYCODE_DPAD_DOWN: return "ArrowDown";
            case KeyEvent.KEYCODE_DPAD_LEFT: return "ArrowLeft";
            default: return "ArrowRight";
        }
    }

    private void pageKey(String key, KeyEvent event) {
        WebView player = web;
        player.evaluateJavascript("window.__streambertTvKey && window.__streambertTvKey("
                + JSONObject.quote(key) + ")", result -> {
            if (web != player || isFinishing() || "true".equals(result)) return;
            if (result != null && result.startsWith("[")) {
                try {
                    JSONArray position = new JSONArray(result);
                    if ("anime-audio".equals(position.optString(0))) {
                        Uri destination = animeAudioDestination(position.optString(1));
                        if ("Enter".equals(key) && destination != null) switchAnimeAudio(destination);
                        return;
                    }
                    View target = inputSurface();
                    tapAt(target, (float) position.getDouble(0) * target.getWidth(),
                            (float) position.getDouble(1) * target.getHeight());
                    return;
                } catch (JSONException ignored) {
                }
            }
            int code = event.getKeyCode();
            if ("vidnest.fun".equalsIgnoreCase(source.getHost())
                    && (key.startsWith("Arrow") || "Enter".equals(key))) return;
            if (key.startsWith("Arrow")) {
                if (!pointerMode) setPointerMode(true);
                movePointer(code);
            } else if ("Enter".equals(key)) {
                setPointerMode(true);
                tap();
            } else {
                View target = inputSurface();
                target.dispatchKeyEvent(event);
                target.dispatchKeyEvent(KeyEvent.changeAction(event, KeyEvent.ACTION_UP));
            }
        });
    }

    private View inputSurface() {
        return fullscreen == null ? web : fullscreen;
    }

    private void setPointerMode(boolean enabled) {
        pointerMode = enabled;
        if (!enabled) {
            cursor.setVisibility(View.INVISIBLE);
            return;
        }
        View target = inputSurface();
        pointerX = target.getWidth() / 2f;
        pointerY = target.getHeight() / 2f;
        showPointer();
    }

    private void showPointer() {
        cursor.setVisibility(View.VISIBLE);
        cursor.setX(pointerX - cursor.getPaint().measureText("⊕") / 2);
        cursor.setY(pointerY - cursor.getTextSize() * 0.75f);
    }

    private void movePointer(int code) {
        if (!pointerMode) setPointerMode(true);
        View target = inputSurface();
        float previousX = pointerX;
        float previousY = pointerY;
        float step = Math.max(8, Math.min(target.getWidth(), target.getHeight()) / 30f);
        if (code == KeyEvent.KEYCODE_DPAD_LEFT) pointerX -= step;
        if (code == KeyEvent.KEYCODE_DPAD_RIGHT) pointerX += step;
        if (code == KeyEvent.KEYCODE_DPAD_UP) pointerY -= step;
        if (code == KeyEvent.KEYCODE_DPAD_DOWN) pointerY += step;
        pointerX = Math.max(2, Math.min(target.getWidth() - 3, pointerX));
        pointerY = Math.max(2, Math.min(target.getHeight() - 3, pointerY));
        showPointer();
        long now = SystemClock.uptimeMillis();
        MotionEvent hover = MotionEvent.obtain(now, now, MotionEvent.ACTION_HOVER_MOVE, pointerX, pointerY, 0);
        hover.setSource(InputDevice.SOURCE_MOUSE);
        target.dispatchGenericMotionEvent(hover);
        hover.recycle();
        if (previousX == pointerX && previousY == pointerY) scrollPointer(target, code, now);
    }

    private void scrollPointer(View target, int code, long now) {
        MotionEvent.PointerProperties mouse = new MotionEvent.PointerProperties();
        mouse.id = 0;
        mouse.toolType = MotionEvent.TOOL_TYPE_MOUSE;
        MotionEvent.PointerCoords position = new MotionEvent.PointerCoords();
        position.x = pointerX;
        position.y = pointerY;
        if (code == KeyEvent.KEYCODE_DPAD_UP) position.setAxisValue(MotionEvent.AXIS_VSCROLL, 1);
        if (code == KeyEvent.KEYCODE_DPAD_DOWN) position.setAxisValue(MotionEvent.AXIS_VSCROLL, -1);
        if (code == KeyEvent.KEYCODE_DPAD_LEFT) position.setAxisValue(MotionEvent.AXIS_HSCROLL, -1);
        if (code == KeyEvent.KEYCODE_DPAD_RIGHT) position.setAxisValue(MotionEvent.AXIS_HSCROLL, 1);
        MotionEvent scroll = MotionEvent.obtain(now, now, MotionEvent.ACTION_SCROLL, 1,
                new MotionEvent.PointerProperties[]{mouse}, new MotionEvent.PointerCoords[]{position},
                0, 0, 1, 1, 0, 0, InputDevice.SOURCE_MOUSE, 0);
        target.dispatchGenericMotionEvent(scroll);
        scroll.recycle();
    }

    private void tap() {
        View target = inputSurface();
        if (!pointerMode) setPointerMode(true);
        tapAt(target, pointerX, pointerY);
    }

    private void tapAt(View target, float x, float y) {
        long now = SystemClock.uptimeMillis();
        for (int action : new int[]{MotionEvent.ACTION_DOWN, MotionEvent.ACTION_UP}) {
            MotionEvent touch = MotionEvent.obtain(now, now, action, x, y, 0);
            touch.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            target.dispatchTouchEvent(touch);
            touch.recycle();
        }
    }

    private void samplePlayback(boolean publish) {
        samplePlayback(publish, null);
    }

    private void samplePlayback(boolean publish, Runnable onSampled) {
        if (mediaItem == null || web == null) {
            if (onSampled != null) onSampled.run();
            return;
        }
        long generation = ++playbackGeneration;
        web.evaluateJavascript("window.__streambertTvPlayback?.(" + resumeAt + ")", result -> {
            try {
                if (generation != playbackGeneration && onSampled == null) return;
                if (result == null || !result.startsWith("[")) return;
                JSONArray sample = new JSONArray(result);
                if (sample.getBoolean(2)) resumeAt = 0;
                if (resumeAt == 0) {
                    lastPosition = sample.getDouble(0);
                    lastDuration = sample.getDouble(1);
                    storePlayback(publish);
                    if (!publish && sample.optBoolean(3)) checkEpisodeAutoplay();
                }
            } catch (JSONException ignored) {
            } finally {
                if (onSampled != null) onSampled.run();
            }
        });
    }

    private void checkEpisodeAutoplay() {
        String key = mediaItem.optString("key");
        if (autoplayChecked || !playbackActive || backPending || !key.startsWith("tv_")
                || path(source).startsWith("/anime/")) return;
        autoplayChecked = true;
        CatalogPlayback.requestAutoplay(key, result -> {
            if (!playbackActive || autoplayCancelled || backPending || isFinishing()) return;
            int seconds;
            try {
                seconds = Integer.parseInt(result);
            } catch (NumberFormatException ignored) {
                return;
            }
            if (seconds < 1 || seconds > 60) return;
            Toast.makeText(this, "Next episode in " + seconds + " seconds. Press Back to cancel.",
                    Toast.LENGTH_LONG).show();
            playbackHandler.postDelayed(advanceEpisode, seconds * 1000L);
        });
    }

    private void storePlayback(boolean publish) {
        if (mediaItem != null && mediaItem.optBoolean("trackProgress", true) && lastDuration > 0) {
            CatalogPlayback.record(this, mediaItem, source.toString(), mediaUserAgent, lastPosition, lastDuration, publish);
        }
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            finish();
            return;
        }
        if (backPending) return;
        playbackHandler.removeCallbacks(advanceEpisode);
        if (autoplayChecked) autoplayCancelled = true;
        backPending = true;
        WebView player = web;
        player.evaluateJavascript("Boolean(window.__streambertTvBack && window.__streambertTvBack())", result -> {
            backPending = false;
            if (web != player || isFinishing() || "true".equals(result)) return;
            leavePlaybackLayer();
        });
    }

    private void leavePlaybackLayer() {
        if (fullscreen != null) leaveFullscreen();
        else if (pointerMode) setPointerMode(false);
        else {
            backPending = true;
            playbackHandler.removeCallbacks(playbackTick);
            samplePlayback(true, this::finish);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        playbackActive = false;
        if (autoplayChecked) autoplayCancelled = true;
        playbackHandler.removeCallbacks(advanceEpisode);
        if (web != null) {
            playbackHandler.removeCallbacks(playbackTick);
            storePlayback(true);
            samplePlayback(true);
            web.evaluateJavascript("document.querySelectorAll('video,audio').forEach(media => media.pause())", null);
            web.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        playbackActive = true;
        if (web != null) {
            web.onResume();
            playbackHandler.removeCallbacks(playbackTick);
            playbackHandler.postDelayed(playbackTick, 1000);
        }
    }

    @Override
    protected void onDestroy() {
        playbackHandler.removeCallbacks(playbackTick);
        playbackHandler.removeCallbacks(advanceEpisode);
        if (web != null) {
            leaveFullscreen();
            web.stopLoading();
            stage.removeView(web);
            web.destroy();
            web = null;
        }
        if (current.get() == this) current.clear();
        MainActivity.notifyPlayerClosed();
        if (advancingEpisode) CatalogPlayback.playNextEpisode(mediaItem.optString("key"));
        super.onDestroy();
    }
}
