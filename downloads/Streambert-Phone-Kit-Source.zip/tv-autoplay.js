export default function bindTvAutoplay({ key, next, play, restricted, getPreference }) {
  if (!window.streambertAndroidTV || !key || !next || restricted) return;

  function delay() {
    if (!(getPreference('AUTOPLAY_NEXT_ENABLED') ?? true)) return 0;
    const seconds = Number(getPreference('AUTOPLAY_NEXT_DURATION') ?? 5);
    return Number.isInteger(seconds) && seconds > 0 && seconds <= 60 ? seconds : 0;
  }

  const check = event => {
    if (event.detail?.key === key) event.detail.delay = delay();
  };
  const advance = event => {
    if (event.detail === key && delay()) play(next);
  };
  window.addEventListener('streambert:tv-autoplay-check', check);
  window.addEventListener('streambert:tv-autoplay-next', advance);
  return () => {
    window.removeEventListener('streambert:tv-autoplay-check', check);
    window.removeEventListener('streambert:tv-autoplay-next', advance);
  };
}
