package com.truelockmc.streambert.probe;

import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.tv.TvContract.WatchNextPrograms;
import android.os.Bundle;
import android.os.SystemClock;
import org.json.JSONObject;

public final class PlayNextProbe extends Instrumentation {
    private boolean holdForLauncher;
    @Override
    public void onCreate(Bundle arguments) {
        super.onCreate(arguments);
        holdForLauncher = "true".equals(arguments.getString("holdForLauncher"));
        start();
    }

    private boolean contains(Context context, String key, int position) {
        try (Cursor cursor = context.getContentResolver().query(WatchNextPrograms.CONTENT_URI,
                new String[]{"internal_provider_id", "last_playback_position_millis", "intent_uri", "browsable"},
                null, null, null)) {
            if (cursor == null) throw new IllegalStateException("Provider returned no cursor");
            while (cursor.moveToNext()) {
                if (key.equals(cursor.getString(0)) && position == cursor.getInt(1)
                        && cursor.getString(2).contains("com.truelockmc.streambert.PLAY_NEXT")) {
                    try {
                        Intent link = Intent.parseUri(cursor.getString(2), Intent.URI_INTENT_SCHEME);
                        link.setComponent(null).setPackage(context.getPackageName()).addCategory(Intent.CATEGORY_BROWSABLE);
                        if (link.resolveActivity(context.getPackageManager()) == null) {
                            throw new IllegalStateException("Play Next deep link does not resolve");
                        }
                        if (cursor.getInt(3) != 1) throw new IllegalStateException("Play Next row is not browsable");
                        return true;
                    } catch (java.net.URISyntaxException error) {
                        throw new IllegalStateException(error);
                    }
                }
            }
            return false;
        }
    }

    @Override
    public void onStart() {
        Bundle result = new Bundle();
        Context target = getTargetContext();
        String key = "movie_" + System.currentTimeMillis();
        try {
            Class<?> playback = target.getClassLoader().loadClass("com.truelockmc.streambert.CatalogPlayback");
            java.lang.reflect.Method record = playback.getDeclaredMethod("record",
                    Context.class, JSONObject.class, String.class, String.class, double.class, double.class, boolean.class);
            record.setAccessible(true);
            JSONObject item = new JSONObject().put("key", key).put("title", "Streambert Play Next test");
            try {
                runOnMainSync(() -> invoke(record, target, item, 45));
                long timeout = SystemClock.uptimeMillis() + 3000;
                while (!contains(target, key, 45000) && SystemClock.uptimeMillis() < timeout) SystemClock.sleep(100);
                if (!contains(target, key, 45000)) throw new IllegalStateException("Play Next row was not published");
                result.putString("publish", "PASS: Play Next provider returned the row, playback position and deep link");
                if (holdForLauncher) SystemClock.sleep(12000);
            } finally {
                runOnMainSync(() -> invoke(record, target, item, 199));
                long timeout = SystemClock.uptimeMillis() + 3000;
                while (contains(target, key, 45000) && SystemClock.uptimeMillis() < timeout) SystemClock.sleep(100);
                target.getSharedPreferences("streambert_playback_time", Context.MODE_PRIVATE).edit().remove(key).commit();
            }
            if (contains(target, key, 45000)) throw new IllegalStateException("Test row was not removed");
            result.putString("cleanup", "PASS: Finished fixture was removed");
            finish(android.app.Activity.RESULT_OK, result);
        } catch (Exception error) {
            result.putString("error", android.util.Log.getStackTraceString(error));
            finish(android.app.Activity.RESULT_CANCELED, result);
        }
    }

    private void invoke(java.lang.reflect.Method method, Context target, JSONObject item, double position) {
        try {
            method.invoke(null, target, item, "https://example.com/", "", position, 200d, true);
        } catch (Exception error) {
            throw new IllegalStateException(error);
        }
    }
}
