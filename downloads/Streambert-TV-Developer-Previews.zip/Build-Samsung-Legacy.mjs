import { readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const esbuild = require('./legacy-tv-tools/node_modules/esbuild');
const { parse } = require('./legacy-tv-tools/node_modules/acorn');
const project = resolve(process.argv[2] || 'work/tv-ports/Samsung-Tizen');
const indexFile = join(project, 'index.html');
const source = await readFile(indexFile, 'utf8');
const entry = source.match(/<script type="module"[^>]*src="(\.\/assets\/[^"]+)"[^>]*><\/script>/)?.[1];
if (!entry) throw new Error('Could not locate the catalog module');

const fallback = await readFile(new URL('./samsung-legacy.js', import.meta.url), 'utf8');
const bundledName = './assets/legacy-catalog.js';
const result = await esbuild.build({
  stdin: {
    contents: 'import "./portable-tv.js";\nimport ' + JSON.stringify(entry) + ';',
    resolveDir: project,
  },
  bundle: true, format: 'iife', minify: true, write: false,
  target: 'chrome69',
  define: { 'import.meta.url': '__streambertAssetBase' },
  banner: { js: 'var __streambertAssetBase = new URL("./assets/legacy-catalog.js", document.baseURI).href;\n' + fallback },
});
const bundle = result.outputFiles[0].text;
parse(bundle, { ecmaVersion: 2019, sourceType: 'script' });
await writeFile(join(project, bundledName), bundle);
await writeFile(join(project, 'samsung-legacy.css'), await readFile(new URL('./samsung-legacy.css', import.meta.url), 'utf8'));
const html = source
  .replace(/<script src="\.\/portable-tv\.js"><\/script>/, '')
  .replace(/<link rel="modulepreload"[^>]*>/g, '')
  .replace(/<script type="module"[^>]*><\/script>/, '<script defer src="' + bundledName + '"></script>')
  .replace('</head>', '<link rel="stylesheet" href="./samsung-legacy.css"></head>');
await writeFile(indexFile, html);
const manifestFile = join(project, 'config.xml');
const manifest = await readFile(manifestFile, 'utf8');
if (!manifest.includes('required_version="7.0"')) throw new Error('Unknown Tizen manifest version');
await writeFile(manifestFile, manifest.replace('required_version="7.0"', 'required_version="5.5"'));
console.log('Built and parsed Samsung Chromium 69 bundle.');
