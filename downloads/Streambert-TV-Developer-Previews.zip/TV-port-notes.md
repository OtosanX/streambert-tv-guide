# Streambert TV developer previews

Use the separate phone kit for Fire OS, Android TV, or Google TV. This archive is for developers testing other TV systems. It does not contain a universal phone installer.

## Samsung Tizen

The Samsung-Tizen folder contains the Streambert catalog, the TV adapter, and config.xml. It targets Tizen 5.5 and Chromium 69, the combination Samsung lists for 2020 models. It uses an older-browser bundle and layout fallbacks. Physical TV compatibility and provider playback remain unverified.

1. On a computer, install Tizen Studio with the Samsung TV and Certificate extensions.
2. Enable Developer Mode on the TV and register the computer's local IP in the TV's developer options. Connect in Tizen Studio's Device Manager.
3. Import the folder as a TV Web application. Create a Samsung certificate profile that authorizes the target TV, then sign and run the project. A generic APK or unsigned archive cannot be installed on the TV.

[Samsung's device setup instructions](https://developer.samsung.com/smarttv/develop/getting-started/using-sdk/tv-device.html)

## LG webOS

The LG-webOS folder is the web app project. The separate com.streambert.tvpreview_2.7.1_all.ipk, when supplied, is its developer package.

1. Enable LG's Developer Mode app and connect a computer to the TV using the webOS CLI or webOS Studio. Follow the LG instructions for retrieving the TV's developer key.
2. With a TV device named my-tv, run `ares-install -d my-tv com.streambert.tvpreview_2.7.1_all.ipk`, then `ares-launch -d my-tv com.streambert.tvpreview`.
3. To rebuild the IPK, run `ares-package --no-minify ./LG-webOS`.

[LG's Developer Mode instructions](https://webostv.developer.lge.com/develop/getting-started/developer-mode-app)

## Amazon Vega

WebView-preview contains the web content and vega-App.tsx is an SDK template adapter. Create a Vega WebView project with the official SDK on supported macOS or Ubuntu, use the adapter for src/App.tsx, and include the preview web files under assets/streambert/ so the WebView can find /pkg/assets/streambert/index.html. Use Amazon's WebView template configuration for the renderer service and network access. Verify local module and network loading on the target software before packaging. Use Amazon's developer signing and Developer Mode to install a .vpkg. No Vega package was built here.

[Vega SDK setup](https://developer.amazon.com/docs/vega/latest/install-vega-sdk) · [WebView integration](https://developer.amazon.com/docs/vega/2.0/develop-your-app-with-webview)

## What to test

The previews reuse the dark catalog, Search, and the TMDB setup QR. They use separate local app storage, and a TMDB token must be entered on first launch. The web preview stores this token in its app storage rather than the Android keystore. Use only your own token and avoid hosting the preview on a public site.

The web adapter restricts player origins and blocks pop-ups and top-level redirects from embedded frames. Individual providers can refuse embedding, render ads inside their frame, or handle the remote differently. The browser preview has no native Android playback-progress bridge. Test playback, Back in an embedded player, and D-pad behavior on a real TV before sharing these previews as a family install.

Use the separate Roku developer ZIP and installation guide for Roku. Apple TV and other app formats are outside these builds.
