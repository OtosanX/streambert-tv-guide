if (!Object.fromEntries) {
  Object.fromEntries = entries => {
    const result = {};
    for (const entry of entries) {
      Object.defineProperty(result, entry[0], {
        value: entry[1], writable: true, enumerable: true, configurable: true,
      });
    }
    return result;
  };
}

if (!window.queueMicrotask) window.queueMicrotask = callback => Promise.resolve().then(callback);

if (window.AbortSignal && !AbortSignal.timeout) {
  AbortSignal.timeout = milliseconds => {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), milliseconds);
    return controller.signal;
  };
}

const nativeScrollIntoView = Element.prototype.scrollIntoView;
Element.prototype.scrollIntoView = function (options) {
  if (options && typeof options === 'object' && options.behavior === 'instant') {
    return nativeScrollIntoView.call(this, { ...options, behavior: 'auto' });
  }
  return nativeScrollIntoView.call(this, options);
};
